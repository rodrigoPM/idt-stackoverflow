// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading, cleaning and writing process in the raw layer of the comments table that will be used for the construction of the Dimensional Model

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Definition of important Global values

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los resultados de las transformaciones sobre las columnas de las tablas que se utilizaran en este notebook

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y sav
val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "comments.parquet"

//2. val que contendra el directorio  de la capa raw-layer del bucket de S3 ,donde se almacenara la nueva version de la tabla comments
val fileLocationRawComments = s"gs://$bucketName/$layerName/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC ##### 2. Table Comments
// MAGIC 
// MAGIC * Schema corresponding to the comments table, which comes from a dataset in csv format 
// MAGIC 
// MAGIC | Column name |  Type    | 
// MAGIC | ----------- |  ------- | 
// MAGIC | id          |  Integer | 
// MAGIC | text        |  String  | 
// MAGIC | creation_date |  Timestamp |
// MAGIC | post_id     |  Integer   |
// MAGIC | user_id     |  Integer   |
// MAGIC | user_display_name|  String   |
// MAGIC | score       |  Integer   |

// COMMAND ----------

// Celda que albergara codigo correspondiente ala  Lectura y creacion del Dataframe comments
 
//File location and type
val fileLocation = "s3://idt115-stackoverflow/dataprep/pm15007/comments.csv/"
val fileType = "csv"

//CSV options
val inferSchema = "True"
val firstRowIsHeader = "False"
val delimiter = ","

//The applied options are for CSV files. For other file types, these will be ignored.
val commentsDF =    spark.read.format(fileType) 
                   .option("inferSchema", inferSchema) 
                   .option("header", firstRowIsHeader) 
                   .option("sep", delimiter) 
                   .option("quote", "\"")
                   .option("escape", "\\") 
                   .option("escape", "\"")
                   .option("multiline", "true") 
                   .load(fileLocation)


// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de renombrado de las columnas resultantes luego de la creacion del dataframe

//Operacion de renombrado de todas las columnas del dataframe recien creado 
val renameColumnCommentsDF = commentsDF.withColumnRenamed("_c0","id")
                            .withColumnRenamed("_c1","text")
                            .withColumnRenamed("_c2","creation_date")
                            .withColumnRenamed("_c3","post_id")
                            .withColumnRenamed("_c4","user_id")
                            .withColumnRenamed("_c5","user_display_name")
                            .withColumnRenamed("_c6","score")
                      

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de filtrado para todos los registros no nulos y la correspondiente impresion de los resutados


//Operacion de filtrado para todos aquellos registros cuyo id sea diferente de null 
val filterColumnCommentsDF= renameColumnCommentsDF.filter($"id".isNotNull)
     
//Operacion de Impresion del dataframe resultante 
filterColumnCommentsDF.show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Writing process of results in the Raw-Layer layer for the new comments table

// COMMAND ----------

//Proceso de Escritura 

      filterColumnCommentsDF
      .write
      .option("compression","snappy")
      .mode("overwrite")
      .parquet(fileLocationRawComments)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Visualization of Results stored in the S3 bucket partition

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa raw layer

//display(dbutils.fs.ls(fileLocationRawComments))


//Visualiazacion del Dataframe correspondiente ala nueva tabla badges en la capa raw layer
var commentsNewDF = spark.read.parquet(fileLocationRawComments)
display(commentsNewDF)