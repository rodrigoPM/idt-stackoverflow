// Databricks notebook source
// MAGIC %md
// MAGIC #post_history table
// MAGIC ####Reading table

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val rowLayer = "raw-layer"
val stagingLayer = "staging-layer"

val location = s"gs://$bucketName/$rowLayer/post_history.parquet/"
val destination = s"gs://$bucketName/$stagingLayer/post_history.parquet"

val rowTable = spark.read
  .option("sep", ",")
  .option("header", true)
  .option("inferSchema", true)
  .parquet(location)

rowTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC ###Schema
// MAGIC | Column name             |  Type      | 
// MAGIC | -----------             |  -------   | 
// MAGIC | id                      |  Integer   | 
// MAGIC | creation_date           |  Timestamp | 
// MAGIC | post_id                 |  Integer   |
// MAGIC | post_history_type_id    |  Integer   |
// MAGIC | revision_guid           |  String    |
// MAGIC | user_id                 |  Integer   |

// COMMAND ----------

// MAGIC %md
// MAGIC ##Drop unused columns

// COMMAND ----------

// Drop unused columns 
val postHistory = rowTable
  .drop("text", "comment")
  .withColumnRenamed("user_id", "temp_user_id")
  
postHistory.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Replacing null values

// COMMAND ----------

// Checking null values for user_id column
val validPostHistory = postHistory
  .select(col("id"), col("creation_date"), col("post_id"), col("post_history_type_id"), col("revision_guid"),
   (when(post_history("temp_user_id").isNotNull, col("temp_user_id"))
  .otherwise(0)).alias("user_id"))

validPostHistory.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ##Save data to staging layer

// COMMAND ----------

validPostHistory.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);