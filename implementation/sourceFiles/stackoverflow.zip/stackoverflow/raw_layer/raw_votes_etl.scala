// Databricks notebook source
// MAGIC %md
// MAGIC #Votes table
// MAGIC ###Reading table

// COMMAND ----------

import org.apache.spark.sql.functions._

val location = "s3://idt115-stackoverflow/dataprep/pm15007/votes.csv/"

val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "votes.parquet"

val destination = s"gs://$bucketName/$layerName/$tableName"

val dirtytable = spark.read
  .option("sep", ",")
  .option("header", false)
  .option("inferSchema", true)
  .csv(location)

dirtytable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC ###Schema
// MAGIC | Column name     |  Type    | 
// MAGIC | -----------     |  ------- | 
// MAGIC | id              |  Integer | 
// MAGIC | creation_date   |  Timestamp  | 
// MAGIC | post_id         |  Integer |
// MAGIC | vote_type_id    |  Integer  |

// COMMAND ----------

// MAGIC %md
// MAGIC ##Set column name

// COMMAND ----------

// Set correct names to columns
val votes = dirtytable
  .withColumnRenamed("_c0", "id")
  .withColumnRenamed("_c1", "creation_date")
  .withColumnRenamed("_c2", "post_id")
  .withColumnRenamed("_c3", "vote_type_id")

votes.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Verifying ids not null

// COMMAND ----------

println(votes.count())
val validVotes = votes.filter(col("id").isNotNull)
println(validVotes.count())
validVotes.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ##Save data to raw layer

// COMMAND ----------

validVotes.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);