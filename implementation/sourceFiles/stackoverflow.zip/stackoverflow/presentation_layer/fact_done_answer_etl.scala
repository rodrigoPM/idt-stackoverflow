// Databricks notebook source
// MAGIC %md
// MAGIC # Fact_done_answer ETL
// MAGIC 
// MAGIC 1. **Description:**  Contains all events when occur a answer
// MAGIC 2. **Granularity:** A record represents a answer
// MAGIC 3. **Uniqueness Policy:** Etl will build a record in the fact table based on the new answers to the questions asked in StakOverflow.
// MAGIC 4. **Invalidity policy:** All fields are required.
// MAGIC 5. **Policy of absence of context:** When a dimension does not apply to a row of the fact, a foreign key will be defined to indicate the absence of data from it.
// MAGIC 
// MAGIC | Column name            | Display name           | Type    | Source                                    | Comment                                    | Sample |
// MAGIC | ---------------------- | ---------------------- | ------- | ----------------------------------------- | ------------------------------------------ | ------ |
// MAGIC | time_key               | Time key               | Integer | Dim_Time.time_key                         | Foreign key pointing to Dim_Time           | -      |
// MAGIC | date_key               | Date key               | Integer | Dim_Date.date_key                         | Foreign key pointing to Dim_Date           | -      |
// MAGIC | user_key               | User key               | String  | Dim_User.user_key                         | Foreign key pointing to Dim_User           | -      |
// MAGIC | score                  | Score                  | Integer | stakoverflow =>post_answer.score          | -                                          | 5      |
// MAGIC | comment_count          | Comment count          | Integer | stakoverflow =>post_answer.comment_count  | -                                          | 4      |
// MAGIC | revision_count         | Revision count         | Integer | stakoverflow =>post_history.post_id       | Calculater ETL                             | 1      |
// MAGIC | fact_done_question_key | Fact done question key | String  | Fact_Done_Question.fact_done_question_key | Foreing Key pointing to Fact_Done_Question | ab-cef |
// MAGIC | fact_done_answer_key   | Fact done answer key   | String  | -                                         | Primary key generated to Fact_Done_Answer  | hi-jkl |
// MAGIC | dd_answer_key          | DD answer key          | Integer | Dim_answer.id_answer_nk                   | -                                          | 7      |

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val staging = "staging-layer"
val presentation = "presentation-layer"

val factAnswer = "fact_done_answer.parquet"
val dateDim = "dim_date.parquet"
val timeDim = "dim_time.parquet"
val userDim = "dim_user.parquet"
val answerDim = "dim_answer.parquet"
val factQuestion = "fact_done_question.parquet"

val postHistory = "post_history.parquet"

val datePath = s"gs://$bucketName/$presentation/$dateDim"
val timePath = s"gs://$bucketName/$presentation/$timeDim"
val userPath = s"gs://$bucketName/$presentation/$userDim"
val answerPath = s"gs://$bucketName/$presentation/$answerDim"

val factQuestionPath = s"gs://$bucketName/$presentation/$factQuestion"
val factAnswerPath = s"gs://$bucketName/$presentation/$factAnswer"

val postHistoryPath = s"gs://$bucketName/$staging/$postHistory"

// COMMAND ----------

// MAGIC %md
// MAGIC ###Reading dimensions and fact done question

// COMMAND ----------

val dateDim = spark.read.option("inferSchema", "true").parquet(datePath)
display(dateDim)

// COMMAND ----------

val timeDim = spark.read.option("inferSchema", "true").parquet(timePath)
display(timeDim)

// COMMAND ----------

val userDim = spark.read.option("inferSchema", "true").parquet(userPath)
display(userDim)

// COMMAND ----------

val answerDim = spark.read.option("inferSchema", "true").parquet(answerPath)
display(answerDim)

// COMMAND ----------

val factQuestion = spark.read.option("inferSchema", "true").parquet(factQuestionPath)
display(factQuestion)

// COMMAND ----------

// MAGIC %md
// MAGIC ### Creating Fact done answer

// COMMAND ----------

val factDoneAnswer = answerDim.join(userDim, col("owner_user_id") === col("id_user_nk"), "inner")
   .join(dateDim, col("id_creation_date") === col("date_key"), "inner")
   .join(timeDim, col("id_creation_time") === col("time_key"), "inner")
   .join(factQuestion.select("dd_question_key", "fact_done_question_key"), col("parent_id") === col("dd_question_key"), "inner")
   .withColumnRenamed("id_answer_nk", "dd_answer_key")
   .withColumn("fact_done_answer_key", expr("uuid()"))
   .select("answer_key", "time_key", "date_key", "user_key","fact_done_question_key", "score", "comment_count", "dd_answer_key", "fact_done_answer_key")
display(factDoneAnswer)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Reading post history

// COMMAND ----------

val postHistory = spark.read.option("inferSchema", "true").parquet(postHistoryPath).groupBy("post_id").count()
display(postHistory)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Adding revision count to Fact Done Question and writing

// COMMAND ----------

val finalFactDoneQuestion = factDoneQuestion.join(postHistory, col("dd_question_key") === col("post_id"), "left")
                                            .withColumnRenamed("count", "revision_count")
                                            .drop("post_id")
                                            .na.fill(0, Seq("revision_count"))

display(finalFactDoneQuestion)

// COMMAND ----------

finalFactDoneQuestion.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(factQuestionPath);

// COMMAND ----------

// MAGIC %md
// MAGIC ###Adding revision count to Fact Done Answer and writing

// COMMAND ----------

val finalFactDoneAnswer = factDoneAnswer.join(postHistory, col("dd_answer_key") === col("post_id"), "left")
                                            .withColumnRenamed("count", "revision_count")
                                            .drop("post_id")
                                            .na.fill(0, Seq("revision_count"))
display(finalFactDoneAnswer)

// COMMAND ----------

finalFactDoneAnswer.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(factAnswerPath);

// COMMAND ----------

// MAGIC %md
// MAGIC ###Saving Answer dimension

// COMMAND ----------

val finalAnswerDim = answerDim.select("answer_key", "id_answer_nk", "creation_date", "last_edit_date", "last_activity_date")
display(finalAnswerDim)

// COMMAND ----------

finalAnswerDim.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(answerPath);