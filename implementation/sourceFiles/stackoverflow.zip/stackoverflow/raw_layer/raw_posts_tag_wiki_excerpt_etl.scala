// Databricks notebook source
// MAGIC %md
// MAGIC #posts_tag_wiki_excerpt table
// MAGIC ####Reading table

// COMMAND ----------

import org.apache.spark.sql.functions._
val location = "s3://idt115-stackoverflow/dataprep/pm15007/posts_tag_wiki_excerpt_1.csv/"

val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "posts_tag_wiki_excerpt.parquet"

val destination = s"gs://$bucketName/$layerName/$tableName"

val dirtyTable = spark.read
  .option("sep", ",")
  .option("header", false)
  .option("inferSchema", true)
  .option("quote", "\"")
  .option("escape", "\\")
  .option("escape", "\"")
  .option("multiline", true)
  .csv(location)

dirtyTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC ###Schema
// MAGIC | Column name             |  Type    | 
// MAGIC | -----------             |  ------- | 
// MAGIC | id                      |  Integer | 
// MAGIC | title                   |  String  | 
// MAGIC | body                    |  String |
// MAGIC | accepted_answer_id      |  String   |
// MAGIC | answer_count            |  String   |
// MAGIC | comment_count           |  Integer   |
// MAGIC | community_owned_date    |  Timestamp   |
// MAGIC | creation_date           |  Timestamp   |
// MAGIC | favorite_count          |  String   |
// MAGIC | last_activity_date      |  Timestamp   |
// MAGIC | last_edit_date          |  Timestamp   |
// MAGIC | last_editor_display_name|  String   |
// MAGIC | last_editor_user_id     |  Integer   |
// MAGIC | owner_display_name      |  String   |
// MAGIC | owner_user_id           |  Integer   |
// MAGIC | parent_id               |  String   |
// MAGIC | post_type_id            |  Integer   |
// MAGIC | score                   |  Integer   |
// MAGIC | tags                    |  String   |
// MAGIC | view_count              |  String   |

// COMMAND ----------

// MAGIC %md
// MAGIC ##Set column name

// COMMAND ----------

// Set correct names to columns
val postsTagWikiExcerpt = dirtyTable
  .withColumnRenamed("_c0","id")
  .withColumnRenamed("_c1","title")
  .withColumnRenamed("_c2","body")
  .withColumnRenamed("_c3","accepted_answer_id")
  .withColumnRenamed("_c4","answer_count")
  .withColumnRenamed("_c5","comment_count")
  .withColumnRenamed("_c6","community_owned_date")
  .withColumnRenamed("_c7","creation_date")
  .withColumnRenamed("_c8","favorite_count")
  .withColumnRenamed("_c9","last_activity_date")
  .withColumnRenamed("_c10","last_edit_date")
  .withColumnRenamed("_c11","last_editor_display_name")
  .withColumnRenamed("_c12","last_editor_user_id")
  .withColumnRenamed("_c13","owner_display_name")
  .withColumnRenamed("_c14","owner_user_id")
  .withColumnRenamed("_c15","parent_id")
  .withColumnRenamed("_c16","post_type_id")
  .withColumnRenamed("_c17","score")
  .withColumnRenamed("_c18","tags")
  .withColumnRenamed("_c19","view_count")

postsTagWikiExcerpt.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Verifying ids not null

// COMMAND ----------

println(postsTagWikiExcerpt.count())
val validPostsTagWikiExcerpt = postsTagWikiExcerpt.filter(col("id").isNotNull)
println(validPostsTagWikiExcerpt.count())
validPostsTagWikiExcerpt.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ##Save data to raw layer

// COMMAND ----------

validPostsTagWikiExcerpt.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);