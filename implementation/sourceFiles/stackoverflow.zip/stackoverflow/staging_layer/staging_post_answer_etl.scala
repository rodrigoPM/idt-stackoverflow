// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading, cleaning and writing process in the staging layer of the badges table that will be used for the construction of the Dimensional Model

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Defining important Global values for the raw-layer partition

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los datos almacenados en la capa Raw layer 

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y save
val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "post_answer.parquet"

//2. val que contendra el directorio  de la capa raw-layer del bucket de S3 ,donde se almacenara la nueva version de la tabla badges
val fileLocationRawPostAnswer = s"gs://$bucketName/$layerName/$tableName"

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Defining important Global values for the staging-layer partition

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los resultados de las transformaciones sobre las columnas de las tablas que se utilizaran en este notebook

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y save
val bucketName = "idt-stackoverflow"
val layerName = "staging-layer"
val tableName = "post_answer.parquet"


//2. val que contendra el directorio de la capa staging-layer del bucket de GCP , donde se almacenara la nueva version de la tabla post_answer
val fileLocationStagingPostAnswer = s"gs://$bucketName/$layerName/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC ##### 1. Table Post_answer
// MAGIC 
// MAGIC * Schema corresponding to the post_answer table stored in the Raw-layer
// MAGIC 
// MAGIC | Column name |  Type    | 
// MAGIC | ----------- |  ------- | 
// MAGIC | id          |  Integer | 
// MAGIC | title        |  String  | 
// MAGIC | body        |  String |
// MAGIC | accepted_answer_id     |  String   |
// MAGIC | answer_count       |  String   |
// MAGIC | comment_count   |  Integer   |
// MAGIC | community_owned_date     |  Timestamp   |
// MAGIC | creation_date       |  Timestamp   |
// MAGIC | favorite_count   |  String   |
// MAGIC | last_activity_date     |  Timestamp   |
// MAGIC | last_edit_date       |  Timestamp   |
// MAGIC | last_editor_display_name   |  String   |
// MAGIC | last_editor_user_id     |  Integer   |
// MAGIC | owner_display_name       | String   |
// MAGIC | owner_user_id   |  Integer   |
// MAGIC | parent_id     |  String   |
// MAGIC | post_type_id       |  Integer   |
// MAGIC | score   |  Integer   |
// MAGIC | tags   |  String   |
// MAGIC | view_count   |  String   |

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Reading the post_answer Dataframe stored in the raw-layer layer

// COMMAND ----------

// Celda que albergara codigo correspondiente ala  Lectura y creacion del Dataframe badges
 
//Lectura del dataframe post_answer e impresion del mismo 
val postAnswerRawDF = spark.read.parquet(fileLocationRawPostAnswer) 

//Operacion de conteo de total de registros operados
println(postAnswerRawDF.count())


// COMMAND ----------

//Impresion del Dataframe recien creado y leido de la capa raw-layer
display(postAnswerRawDF)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Dropping of columns that will not be used for the construction of the Dimensional Model

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de dropeo de las columnas que no se utilizara en la construccion del modelo dimensional 


//Operacion de Dropeo de Columnas que no son aptas para el modelo
val dropColumnAnswerDF= postAnswerRawDF
    .drop("title","accepted_answer_id","answer_count","community_owned_date","favorite_count","last_editor_display_name","last_editor_user_id","owner_display_name","tags","view_count")

//Operacion de Impresion del dataframe resultante 
display(dropColumnAnswerDF)


// COMMAND ----------

// MAGIC %md
// MAGIC ##### Adjustment of fields of type flag, flag or indicators by textual values

// COMMAND ----------

//La correspondiente operacion de ajuste de campos de tipo flag , banderas  e indicadores  para este dataframe de post_answer no requiere de dicha operacion como parte del resultado del data profiling se concluye que la tabla post_answer no posee campos de este tipo

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Adjustment of fields with characteristics of null or empty by textual values

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Attribute: 
// MAGIC 1. last_edit_date

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de filtrado para poder obtener dos Dataframes , el primero contendra todos aquellos registros cuyo campo "last_edit_date"  seran no nulos , el segundo contendra todos aquellos registros cuyo campo last_edit_date seran nulos.

import org.apache.spark.sql.functions._//Importacion de las correspondientes funciones de la libreria general de Funciones.

//Operacion de conteo de total de registros operados
 println(dropColumnAnswerDF.count())

//Operacion de filtrado para el campo "last_edit_date" que contendran valores no nulos
val setNotNulllastPostAnswerDF1 = dropColumnAnswerDF.filter(($"last_edit_date".isNotNull))

println(setNotNulllastPostAnswerDF1.count())

//Operacion de filtrado para el campo "last_edit_date" que contendran valores nulos 
val setIsNulllastPostAnswerDF1 = dropColumnAnswerDF.filter(($"last_edit_date".isNull)) 

//Operacion de conteo de total de registros operados
println(setIsNulllastPostAnswerDF1.count())
  
//Impresion del Dataframe de los nulos para los cuales se le aplicaran posteriormente operaciones o transformaciones
setIsNulllastPostAnswerDF1.show()

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de ajuste del campo "last_edit_date"  cuyo contenido es nulo , aplicando operaciones de creacion de nuevas columnas en base al valor de otras columnas existentes de tal manera se lograra ganar mayor capacidad analitica.

import org.apache.spark.sql.functions._//Importacion de las correspondientes funciones de la libreria general de Funciones.
 

//Operacion de creacion de nueva columna ,para la correspondiente sustitucion de los valores nulos por valores contenidos en la columna "creation_date"
val setlastNullPostAnswerDF2 =  setIsNulllastPostAnswerDF1 .withColumn("last_edit_date",$"creation_date")   

//Impresion del dataframe resultante que contendra para la columna last_edit_date sus correspondientes valores ajustados
display(setlastNullPostAnswerDF2)

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de union de los Dataframes recien creados y manipulados , el primero de ellos representa a todos aquellos registros cuyos campos "last_edit_date" son no nulos , el segundo Dataframe contiene todos aquellos registros para los cuales la columna  posee los valores ajustados , es decir los valores textuales.


import org.apache.spark.sql.functions._ //Importacion de las correspondientes funciones de la libreria general de Funciones.

//Operacion de union que permite unir los registros limpios del primer dataframe filtrado y los registros ajustados del Dataframe para los que las columnas mencionadas ya no poseen valores null.
val setlastNullPostAnswerDF3 =  setNotNulllastPostAnswerDF1.unionByName(setlastNullPostAnswerDF2)

//Operacion de conteo de total de registros operados
println(setlastNullPostAnswerDF3.count())

//Impresion del Dataframe de post_answer final , que contiene todos sus registros limpios , es decir columnas con valores no nulos.
setlastNullPostAnswerDF3.show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Atribute: 
// MAGIC 2. owner_user_id

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de filtrado para poder obtener dos Dataframes , el primero contendra todos aquellos registros cuyo campo "owner_user_id seran no nulos , el segundo contendra todos aquellos registros cuyo campo "owner_user_id seran nulos.

import org.apache.spark.sql.functions._//Importacion de las correspondientes funciones de la libreria general de Funciones.
 
 println(dropColumnAnswerDF.count())
//Operacion de filtrado para el campo "owner_user_id" que contendran valores no nulos
val setOwnerNotNullPostAnswerDF1 = setlastNullPostAnswerDF3.filter(($"owner_user_id".isNotNull))

println(setOwnerNotNullPostAnswerDF1.count())

//Operacion de filtrado para el campo "owner_user_id" , que contendran valores nulos 
val setOwnerIsNullPostAnswerDF1 = setlastNullPostAnswerDF3.filter(($"owner_user_id".isNull)) 

//Operacion de conteo de total de registros operados
println(setOwnerIsNullPostAnswerDF1.count())
  
//Impresion del Dataframe de los nulos para los cuales se le aplicaran posteriormente operaciones o transformaciones
setOwnerIsNullPostAnswerDF1.show()

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de ajuste del campo owner_user_id" cuyo contenido es nulo a traves de el uso de UDF's para poder sustituir todos aquellos valores nulos por un valor mas textual , de tal manera se lograra ganar mayor capacidad analitica.

import org.apache.spark.sql.functions._//Importacion de las correspondientes funciones de la libreria general de Funciones.


//Operacion de definicion de UDF que ajustara todos los registros de la columna "owner_user_id" cuyo valor es nulo 
def setNullsOwnerId(param1:String):String={
  if(param1 == null){
    "It has no owner id"
  }
  else{
    param1
  }
}

//Operacion de registro de la UDF recien definida para que ya pueda aplicarse bajo el contexto de operaciones sobre Dataframes
val setNullsOwnerIdDF = udf(setNullsOwnerId _)

//Operacion de creacion de nueva columna , para la correspondiente sustitucion de los valores nulos por valores textuales y con logica de negocio 
val setOwnerIsNullPostAnswerDF2 =  setOwnerIsNullPostAnswerDF1.withColumn("owner_user_id",setNullsOwnerIdDF($"owner_user_id")) //Aplicacion de la UDF recien registrada sobre la columna "owner_user_id"

//Impresion del dataframe resultante que contendra para ambas columnas sus correspondientes valores ajustados
setOwnerIsNullPostAnswerDF2.show()

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de union de los Dataframes recien creados y manipulados , el primero de ellos representa a todos aquellos registros cuyo campo "owner_user_id" son no nulos ,  el segundo Dataframe contiene todos aquellos registros para los cuales la columna  posee los valores ajustados , es decir los valores textuales.


import org.apache.spark.sql.functions._ //Importacion de las correspondientes funciones de la libreria general de Funciones.

//Operacion de union que permite unir los registros limpios del primer dataframe filtrado y los registros ajustados del Dataframe para los que las columnas mencionadas ya no poseen valores null.
val setOwnerIsNullPostAnswerDF3 =  setOwnerNotNullPostAnswerDF1.unionByName(setOwnerIsNullPostAnswerDF2)

//Operacion de conteo de total de registros operados 
println(setOwnerIsNullPostAnswerDF3.count())
//Impresion del Dataframe de post_answer final , que contiene todos sus registros limpios , es decir columnas con valores no nulos.
setOwnerIsNullPostAnswerDF3.show()

// COMMAND ----------

//Celda que almacena operacion de filtrado para el campo "owner_user_id", para comprobar el correcto estado de los valores del mismo 
val filter1 = setOwnerIsNullPostAnswerDF3.filter($"owner_user_id"==="It has no owner id")
display(filter1)

// COMMAND ----------

//Celda que almacena operaciones de filtrado para los campos "last_edit_date" , "owner_user_id" para comprobar la inexistencia de registros nulos para ambos campos , de tal manera que se ah obtenido un Dataframe limpio para poder aplicarle las posteriores operaciones


//val filter = setOwnerIsNullPostAnswerDF3.filter($"last_edit_date".isNull).show()
//val filter = setOwnerIsNullPostAnswerDF3.filter($"owner_user_id".isNull).show()
val filter = setOwnerIsNullPostAnswerDF3.filter(($"last_edit_date".isNull)&&($"owner_user_id".isNull)).show()



// COMMAND ----------

// MAGIC %md
// MAGIC ##### Generacion de keys necesarias para las dimensiones de time , date y apoyar operaciones para la construccion del modelo dimensional 

// COMMAND ----------

//Celda que albergara codigo conrrespondiente alas operaciones de creacion de nuevas columnas a partir de campos de tipo timestamp para que las mimas representen keys , haciendo uso de funciones como date_format

val creationKeysPostAnswerDF = setOwnerIsNullPostAnswerDF3.withColumn("id_creation_date",date_format($"creation_date","yyyyMMdd"))
                           .withColumn("id_creation_time",date_format($"creation_date","HHmmss"))
                           .select("id","id_creation_date","id_creation_time","body","comment_count","creation_date","last_activity_date","last_edit_date","owner_user_id","parent_id","post_type_id","score")
                           

//Operacion de impresion del Dataframe final que se almacenada en la capa staging_layer y que sera utilizado para la construccion del modelo dimensional
display(creationKeysPostAnswerDF)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Writing process of results in the Staging-Layer layer for the new badges table

// COMMAND ----------

//Proceso de Escritura 
      creationKeysAnswerDF
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationStagingPostAnswer)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Viewing Results Stored in GCP Bucket Partition

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa staging-layer

//display(dbutils.fs.ls(fileLocationStagingPostAnswer))


//Visualiazacion del Dataframe correspondiente ala nueva tabla badges en la capa staging-layer
var postAnswerNewDF = spark.read.parquet(fileLocationStagingPostAnswer)
println(postAnswerNewDF.count())
postAnswerNewDF.show()
