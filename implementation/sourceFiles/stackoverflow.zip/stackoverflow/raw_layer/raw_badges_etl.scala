// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading, cleaning and writing process in the raw layer of the badges table that will be used for the construction of the Dimensional Model

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Definition of important Global values

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los resultados de las transformaciones sobre las columnas de las tablas que se utilizaran en este notebook

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y save
val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "badges.parquet"

//2. val que contendra el directorio  de la capa raw-layer del bucket de S3 ,donde se almacenara la nueva version de la tabla badges
val fileLocationRawBadges = s"gs://$bucketName/$layerName/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC ##### 1. Table Badges
// MAGIC 
// MAGIC * Schema corresponding to the badges table, which comes from a dataset in csv format
// MAGIC 
// MAGIC | Column name |  Type    | 
// MAGIC | ----------- |  ------- | 
// MAGIC | id          |  Integer | 
// MAGIC | name        |  String  | 
// MAGIC | date        |  Timestamp |
// MAGIC | user_id     |  Integer   |
// MAGIC | class       |  Integer   |
// MAGIC | tag_based   |  boolean   |  

// COMMAND ----------

// Celda que albergara codigo correspondiente ala  Lectura y creacion del Dataframe badgesDF
 
//File location and type
val fileLocation = "s3://idt115-stackoverflow/dataprep/gg13113/badges.csv/"
val fileType = "csv"

//CSV options
val inferSchema = "True"
val firstRowIsHeader = "False"
val delimiter = ","

//The applied options are for CSV files. For other file types, these will be ignored.
val badgesDF =     spark.read.format(fileType) 
                   .option("inferSchema", inferSchema) 
                   .option("header", firstRowIsHeader) 
                   .option("sep", delimiter) 
                   .option("quote", "\"")
                   .option("escape", "\\") 
                   .option("escape", "\"")
                   .option("multiline", "true") 
                   .load(fileLocation)


// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de renombrado de las columnas resultantes luego de la creacion del dataframe 

//Operacion de renombrado de todas las columnas del dataframe recien creado 
val renameColumBadgesDF = badgesDF.withColumnRenamed("_c0","id")
                    .withColumnRenamed("_c1","name")
                    .withColumnRenamed("_c2","date")
                    .withColumnRenamed("_c3","user_id")
                    .withColumnRenamed("_c4","class")
                    .withColumnRenamed("_c5","tag_based")
                    

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de filtrado para todos los registros no nulos y la correspondiente impresion de los resutados

//Operacion de filtrado para todos aquellos registros cuyo id es diferente de null

val filterColumnBadgesDF = renameColumBadgesDF.filter($"id".isNotNull)
                          

//Operacion de Impresion del dataframe resultante 
filterColumnBadgesDF.show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Writing process of results in the Raw-Layer layer for the new badges table

// COMMAND ----------

//Proceso de Escritura 

      filterColumnBadgesDF
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationRawBadges)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Visualization of Results stored in the bucket partition in Cloud Storage

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa raw layer

//display(dbutils.fs.ls(fileLocationRawBadges))


//Visualiazacion del Dataframe correspondiente ala nueva tabla badges en la capa raw layer
var badgesNewDF = spark.read.parquet(fileLocationRawBadges)
display(badgesNewDF)
