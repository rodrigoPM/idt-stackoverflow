// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading, transformation and writing Dim Question in the presentation layer, It is part of the dimensional model

// COMMAND ----------

// MAGIC %md
// MAGIC 
// MAGIC # Dim Question
// MAGIC 
// MAGIC 1. Description: Save the context of the question asked
// MAGIC 2. Granularity: A record represents a question post
// MAGIC 3. Uniqueness policy: The ETL will search the question and assign a surrogate key when this question is not stored in the dimension.
// MAGIC 4. Invalidity policy: All fields are required.
// MAGIC 5. SCD Policy: All fields will be Slowly Changing Dimension type one.
// MAGIC 
// MAGIC | Column name        | Display name       | Type     | Source                                                    | Comment                 | Sample            |
// MAGIC | ------------------ | ------------------ | -------- | --------------------------------------------------------- | ----------------------- | ----------------- |
// MAGIC | question_key       | Question Key       | String   | -                                                         | Surragate key generated | 68d2e3f           |
// MAGIC | id_question_nk     | Id natural key     | Integer  | stakoverflow =>post_question=>id                          | Natural Key             | 4                 |
// MAGIC | title              | Title              | String   | stakoverflow =>post_question=>title                       | -                       | Null pointer java |
// MAGIC | last_activity_date | Last activity date | Timestamp     | stakoverflow =>post_question=>last_activity_date     | -                       | 27/06/2021        |
// MAGIC | last_edit_date     | Last edit date     | Timestamp     | stakoverflow =>post_question=>last_edit_date         | -                       | 27/06/2021        |
// MAGIC | creation_date      | Creation date      | Timestamp     | stakoverflow =>post_question=>creation_date          | -                       | 27/06/2021        |

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Global variables definition for post_questions table

// COMMAND ----------

//Path que contendra el directorio de almacenamiento del Dataframe post_answer del cual se construira la Dim Question

//1. Vals que contendran informacion concerniente al nombre del bucket , capa que albergara las tablas o dataframe a utilizar para la construccion de la dimension
val bucketName = "idt-stackoverflow"
val layerName = "staging-layer"
val tableName = "posts_questions.parquet"


//2. val que contendra el directorio de la capa staging-layer del bucket de GCP , donde esta almacenada  version actual del dataframe post_question
val fileLocationStagingPostQuestions = s"gs://$bucketName/$layerName/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC ##### Global variables definition for dim_question table

// COMMAND ----------

//Path que contendra el directorio de almacenamiento para la nueva Dimension Answer (Dim Question)

//1. Vals que contendran informacion concerniente al nombre del bucket , capa que albergara la nueva Dim Question
val bucketName = "idt-stackoverflow"
val layerName = "presentation-layer"
val tableName = "dim_question.parquet"


//2. val que contendra el directorio de la capa presentation-layer donde se almacenara la Dim Question
val fileLocationPresentDimQuestion = s"gs://$bucketName/$layerName/$tableName"

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Reading post_answer data from the staging layer

// COMMAND ----------

//Celda que albergara codigo correspondiente a operaciones basicas de tratamiento de datos para las columnas id que seran utilizadas para construir la dimension
import org.apache.spark.sql.functions._ //Importacion de las funciones de la libreria general de funciones de spark-sql

//Operacion de lectura del Dataframe correspondiente a post_question desde la capa staging-layer
val postAnswerDF1 = spark.read.parquet(fileLocationStagingPostQuestions) 


// COMMAND ----------

display(postAnswerDF1)

// COMMAND ----------

//Operacion de seleccion y casteo a tipo int para todas las columnas cuyo contenido es id y que formaran parte de la version final de la Dim Question
val newDimQuestionDF1 = postAnswerDF1.select($"id".cast("int"),$"title",$"id_creation_date".cast("int"),$"id_creation_time".cast("int"),$"last_activity_date",$"last_edit_date",$"creation_date",$"favorite_count",
                                         $"score",$"comment_count",$"owner_user_id".cast("int"))
 

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Definition of the Initial Load Operation that will build the Dim Question 

// COMMAND ----------

//Celda que albergara codigo correspondiente a operaciones necesarias para la construccion de la Dim Question 
 
 //Operacion de creacion una nueva columna para la llave subrogada de la Dim Question y seleccion de las columnas finales que conformaran la misma
val newDimQuestionDF2 = newDimQuestionDF.withColumn("question_key",expr("uuid()"))
                    .select($"question_key",$"id".as("id_question_nk"),$"title",$"id_creation_date",$"id_creation_time",$"last_activity_date",$"last_edit_date",$"creation_date",$"score",$"comment_count",$"favorite_count",$"owner_user_id")


//Operacion de impresion del Dataframe correspondiente ala Dim Question
display(newDimQuestionDF2)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Writing process of results in the layer Presentation-Layer

// COMMAND ----------

//Proceso de Escritura 
       newDimQuestionDF2 
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationPresentDimQuestion)