// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading, cleaning and writing process in the staging layer of the badges table that will be used for the construction of the Dimensional Model

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Definicion de valores Globales importantes para la particion raw-layer

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los datos almacenados en la capa Raw layer 

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y save
val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "badges.parquet"

//2. val que contendra el directorio  de la capa raw-layer del bucket de S3 ,donde se almacenara la nueva version de la tabla badges
val fileLocationRawBadges = s"gs://$bucketName/$layerName/$tableName"

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Defining important Global values for the staging-layer partition

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los resultados de las transformaciones sobre las columnas de las tablas que se utilizaran en este notebook

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y save
val bucketName = "idt-stackoverflow"
val layerName = "staging-layer"
val tableName = "badges.parquet"

//2. val que contendra el directorio de la capa staging-layer del bucket de GCP , donde se almacenara la nueva version de la tabla badges
val fileLocationStagingBadges = s"gs://$bucketName/$layerName/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC ##### 1. Table Badges
// MAGIC 
// MAGIC * Schema corresponding to the badges table stored in the Raw-layer
// MAGIC 
// MAGIC | Column name |  Type    | 
// MAGIC | ----------- |  ------- | 
// MAGIC | id          |  Integer | 
// MAGIC | name        |  String  | 
// MAGIC | date        |  Timestamp |
// MAGIC | user_id     |  Integer   |
// MAGIC | class       |  Integer   |
// MAGIC | tag_based   |  boolean   |  

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Reading the Dataframe badges stored in the raw-layer layer

// COMMAND ----------

// Celda que albergara codigo correspondiente ala  Lectura y creacion del Dataframe badges
 
//Lectura del dataframe badges e impresion del mismo 
val badgesRawDF = spark.read.parquet(fileLocationRawBadges)

//Operacion de conteo de total de registros operados
println(badgesRawDF.count())

//Impresion del Dataframe resultante , recien leido de la capa raw-layer
badgesRawDF.show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Dropping of columns that will not be used for the construction of the Dimensional Model

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de dropeo de las columnas que no se utilizara en la construccion del modelo dimensional 

//La correspondiente operacion de dropeo para este dataframe de badges no requiere de dicha operacion como parte del resultado del data profiling se concluye que todos sus campos o columnas se mantendran para la construccion del     modelo dimensional 
                    

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Adjustment of fields of type flag, flag or indicators by textual values 

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de ajuste de flags , indicadores o banderas del campo tag_based por valores mas textuales que permitan dar a conocer de manera textual lo que realmente esta representando ese campo y enriquecer la capacidad analitica que el modelo pueda tener.

import org.apache.spark.sql.functions._ 


//operacion para la creacion de la nueva columna tag_based que contendra valores mas textuales , a travez de la aplicacion de de la funcion when implementada en la libreria general de funciones de spark sql.
 
val flagTagBassedBadgesDF =  badgesRawDF.withColumn("tag_based", when(badgesRawDF("tag_based") === "true", "Badge for label")
                                                    .when(badgesRawDF("tag_based") === "false", "Badge with named"))

//Operacion para la impresion del Dataframe resultante                                                                        
display(flagTagBassedBadgesDF)  
                            

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de ajuste de flags , indicadores o banderas del campo class por valores mas textuales que permitan dar a conocer de manera textual lo que realmente esta representando ese campo y enriquecer la capacidad analitica que el modelo pueda tener.

import org.apache.spark.sql.functions._ 


//operacion para la creacion de la nueva columna tag_based que contendra valores mas textuales , a travez de la aplicacion de de la funcion when implementada en la libreria general de funciones de spark sql.
 
val flagClassBadgesDF =  flagTagBassedBadgesDF.withColumn("class", when(flagTagBassedBadgesDF("class") === 1, "Gold")
                                                    .when(flagTagBassedBadgesDF("class") === 2, "Silver")
                                                    .when(flagTagBassedBadgesDF("class") === 3, "Bronze"))
                                                    
                                                    
//Operacion de conteo de total de registros operados
println(flagClassBadgesDF.count())

//Operacion para la impresion del Dataframe resultant                                                                        
flagClassBadgesDF.show()  

// COMMAND ----------

//Celda que almacena operaciones de filtrado como parte de la comprobacion de las transformaciones hechas sobre las columnas del Dataframe resultante de badges y corroborar tambien la calidad de los datos
//val filterPruebaDF1 = flagClassBadgesDF.filter($"class"==="Silver").show()
val filterPruebaDF2 = flagClassBadgesDF.filter($"tag_based"==="Badge for label").show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Adjustment of fields with characteristics of null or empty by textual values

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de  sustitucion de valores de campos nulos , vacios por valores mas textuales , de tal forma que se esta aplicando una de las tecnicas de modelado dimensional , que busca de ta la manera proveer a dimensiones de valores mas textuales para enriquecer los respectivos analisis.


//La correspondiente operacion de ajuste para campos con valores nulos del dataframe de badges no requiere de dicha operacion como parte del resultado del data profiling se concluye que todos sus campos o columnas no poseen valores nulos , estan lo suficientemente limpios para no requerir de esta operacion


// COMMAND ----------

// MAGIC %md
// MAGIC ##### Writing process of results in the Staging-Layer layer for the new badges table

// COMMAND ----------

//Proceso de Escritura 

      flagClassBadgesDF
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationStagingBadges) 

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Visualization of Results stored in the S3 bucket partition

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa staging-layer

//display(dbutils.fs.ls(fileLocationStagingBadges))


//Visualiazacion del Dataframe correspondiente ala nueva tabla badges en la capa staging-layer
var badgesNewDF = spark.read.parquet(fileLocationStagingBadges)
println(badgesNewDF.count())
badgesNewDF.show()
