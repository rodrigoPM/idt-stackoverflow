// Databricks notebook source
// MAGIC %md
// MAGIC #Posts_questions staging

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val originLayer = "raw-layer"
val detinantionLayer = "staging-layer"
val tableName = "posts_questions.parquet"

val origin = s"gs://$bucketName/$originLayer/$tableName"
val destination = s"gs://$bucketName/$detinantionLayer/$tableName"

val tagsTable = "tags.parquet"
val tagsOrigin = s"gs://$bucketName/$detinantionLayer/$tagsTable"
val tagsDestination = s"gs://$bucketName/$detinantionLayer/$tagsTable"


// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading Questions and tags

// COMMAND ----------

val questions = spark.read.option("inferSchema", "true").parquet(origin)
quetions.printSchema()
display(quetions)

// COMMAND ----------

val tags = spark.read.option("inferSchema", "true").parquet(tagsOrigin).withColumnRenamed("count", "total_count")
tags.printSchema()
display(tags)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Drop unused columns

// COMMAND ----------

val questionsStaging = questions.drop("body")
                                .drop("community_owned_date")
                                .drop("last_editor_display_name")
                                .drop("last_editor_user_id")
                                .drop("owner_display_name")
display(questionsStaging)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Fill null values

// COMMAND ----------

val refillColumnsWithZero = Seq("accepted_answer_id", "answer_count","comment_count", "favorite_count", "score")
val questionsStagingZero =  questionsStaging.na.fill(0, refillColumnsWithZero)
display(questionsStagingZero)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Replace null last_edit_date and last_activity_date

// COMMAND ----------

val newLastEditDate = questionsStagingZero.filter(col("last_edit_date").isNull).withColumn("last_edit_date", col("creation_date"))
val questionsNewLastEditDate = questionsStagingZero.unionByName(newLastEditDate).filter(col("last_edit_date").isNotNull)
display(questionsNewLastEditDate)

// COMMAND ----------

val newLastActivityDate = questionsNewLastEditDate.filter(col("last_activity_date").isNull)
                          .withColumn("last_activity_date", col("last_edit_date"))
val questionsNewLastActivityDate = questionsNewLastEditDate.unionByName(newLastActivityDate).filter(col("last_activity_date").isNotNull)
display(questionsNewLastActivityDate)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Creation id_date, id_time

// COMMAND ----------

import org.apache.spark.sql.types._

val questionsWrite = questionsNewLastActivityDate
      .withColumn("id_creation_date", date_format(col("creation_date"),"yyyyMMdd").cast(IntegerType))
      .withColumn("id_creation_time", date_format(col("creation_date"),"HHmmss").cast(IntegerType))
display(questionsWrite.select("creation_date", "id_creation_date", "id_creation_time"))

// COMMAND ----------

// MAGIC %md
// MAGIC ####Writing questions 

// COMMAND ----------

questionsWrite.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);

// COMMAND ----------

// MAGIC %md
// MAGIC ####Creation tag_bridge

// COMMAND ----------

val questionsTags = questionsWrite.withColumn("tags", split(col("tags"), "[|]")).withColumn("tag", explode(col("tags"))).select("id", "tags", "tag")
display(questionsTags)

// COMMAND ----------

val tagBridge = questionsTags.withColumnRenamed("id", "id_post_question")
                .join(tags.withColumnRenamed("id", "id_tag"), col("tag") === col("tag_name"), "inner").drop("tags", "total_count")
display(tagBridge)

// COMMAND ----------

display(tagBridge.filter(col("id_tag").isNull))

// COMMAND ----------

val tagBridgeWrite = tagBridge.drop("tag", "tag_name")
val bridgeDestination = s"gs://$bucketName/$detinantionLayer/tag_bridge.parquet"

tagBridgeWrite.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(bridgeDestination);