// Databricks notebook source
// MAGIC %md
// MAGIC ##Tag table
// MAGIC ####Reading table

// COMMAND ----------

import org.apache.spark.sql.functions._

val location = "s3://idt115-stackoverflow/dataprep/pm15007/tags.csv/"

val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "tags.parquet"

val destination = s"gs://$bucketName/$layerName/$tableName"

val dirtyTable = spark.read
  .option("sep", ",")
  .option("header", false)
  .option("inferSchema", true)
  .csv(location)

dirtyTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC ###Schema
// MAGIC | Column name     |  Type    | 
// MAGIC | -----------     |  ------- | 
// MAGIC | id              |  Integer | 
// MAGIC | tag_name        |  String  | 
// MAGIC | count           |  Integer |
// MAGIC | excerpt_post_id |  Integer  |
// MAGIC | wiki_post_id    |  Integer  |

// COMMAND ----------

// MAGIC %md
// MAGIC ##Set column name

// COMMAND ----------

// Set correct names to columns
val tags = dirtyTable
  .withColumnRenamed("_c0", "id")
  .withColumnRenamed("_c1", "tag_name")
  .withColumnRenamed("_c2", "count")
  .withColumnRenamed("_c3", "excerpt_post_id")
  .withColumnRenamed("_c4", "wiki_post_id")

tags.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Verifying ids not null

// COMMAND ----------

println(tags.count())
val validTags = tags.filter(col("id").isNotNull)
println(validTags.count())
validTags.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ##Save data to raw layer

// COMMAND ----------

validTags.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);