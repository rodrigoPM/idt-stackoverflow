// Databricks notebook source
// MAGIC %md
// MAGIC #Tags staging

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val originLayer = "raw-layer"
val detinantionLayer = "staging-layer"
val tableName = "tags.parquet"

val origin = s"gs://$bucketName/$originLayer/$tableName"
val destination = s"gs://$bucketName/$detinantionLayer/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading tags

// COMMAND ----------

val rawTags = spark.read.option("inferSchema", "true").parquet(origin)
rawTags.printSchema()
display(rawTags)

// COMMAND ----------

val tags = rawTags.drop("excerpt_post_id").drop("wiki_post_id")
display(tags)

// COMMAND ----------

tags.select("tag_name").filter(col("tag_name").isNull).count

// COMMAND ----------

tags.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);