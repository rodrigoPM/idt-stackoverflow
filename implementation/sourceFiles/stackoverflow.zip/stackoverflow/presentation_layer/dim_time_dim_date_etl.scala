// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading and writing process in the Presentation Layer of the Date Dimension and Time Dimension

// COMMAND ----------

// MAGIC %md
// MAGIC #### Dim_Time
// MAGIC 1. Description: This dimension stores records about time
// MAGIC 2. Granularity: A record represents the time in a day
// MAGIC 3. Uniqueness policy: A record represents the time in a day
// MAGIC 4. Nulliness policy: All fields are required
// MAGIC 5. SCD policy:  All fields use SCD 0
// MAGIC 
// MAGIC | Column name | Display name | Type     | Source | Comment                 | Sample       |
// MAGIC | ----------- | ------------ | -------- | ------ | ----------------------- | ------------ |
// MAGIC | time_key    | Time key     | Integer  | -      | Surragate key generated | 127          |
// MAGIC | time_24h    | Time 24h     | Time     | -      | -                       | 12:01:27 AM  |
// MAGIC | hour        | Hour         | Integer  | -      | -                       | 0            |
// MAGIC | minute      | Minute       | Integer  | -      | -                       | 1            |
// MAGIC | second      | Second       | Integer  | -      | -                       | 27           |
// MAGIC | hour_12     | Hour 12      | Integer  | -      | -                       | 12           |
// MAGIC | time_ampm   | AM-PM        | DateTime | -      | -                       | 12:01:27 a.m |
// MAGIC | period      | Period       | String   | -      | -                       | midnight     |

// COMMAND ----------

// MAGIC %md
// MAGIC #### Dim_Date
// MAGIC 1. Description: This dimension stores records about day
// MAGIC 2. Granularity: A record represents a day in a year
// MAGIC 3. Uniqueness policy: A record represents a day in a year
// MAGIC 4. Nulliness policy: All fields are required
// MAGIC 5. SCD policy:  All fields use SCD 0
// MAGIC 
// MAGIC | Column name  | Display name | Type    | Source | Comment                 | Sample   |
// MAGIC | ------------ | ------------ | ------- | ------ | ----------------------- | -------- |
// MAGIC | date_key     | Date key     | Integer  | -      | Surragate key generated | 20130101 |
// MAGIC | date         | Date         | Date    | -      | -                       | 01/01/13 |
// MAGIC | day_of_week  | Day of week  | Integer | -      | -                       | 1        |
// MAGIC | quarter      | Quarter      | Integer | -      | -                       | 2        |
// MAGIC | year         | Year         | Integer | -      | -                       | 2013     |
// MAGIC | day_name     | Day name     | String  | -      | -                       | Thursday |
// MAGIC | weekday_flag | Weekday flag | String  | -      | -                       | Weekday  |
// MAGIC | month        | Month        | Integer | -      | -                       | 1        |
// MAGIC | month_name   | Month name   | String  | -      | -                       | January  |
// MAGIC | day          | Day          | Integer | -      | -                       | 1        |
// MAGIC | date_num_overall          | Date num overall          | Integer | -      | -                       | 2        |
// MAGIC | date_abbrev          | Date abbrev          | String | -      | -                       | Wed        |
// MAGIC | week_num_in_year          | Week num in year          | Integer | -      | -                       | 2       |
// MAGIC | week_num_overall          | Week num overall          | Integer | -      | -                       | 2        |
// MAGIC | week_beging_date          | Week beging date          | Date    | -      | -                       | 01/01/2021        |
// MAGIC | month_num_overall         | Month num overall         | Integer | -      | -                       | 2        |

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Defining important global values for the Presentation-layer partition

// COMMAND ----------

//Path que contendra el directorio de almacenamiento en el cual se almacenara la dimension de Tiempo.


//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla correspondiente ala Dim Time y  save
val bucketName = "idt-stackoverflow"
val layerName = "presentation-layer"
val tableName = "dim_time.parquet"

//2. val que contendra el directorio de la capa presentation-layer del bucket de GCP , donde se almacenara la Dim Time
val fileLocationPresentDimTime = s"gs://$bucketName/$layerName/$tableName"



// COMMAND ----------

//Path que contendra el directorio de almacenamiento en el cual se almacenara la dimension de Fecha.


//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla correspondiente ala Dim Date y  save
val bucketName = "idt-stackoverflow"
val layerName = "presentation-layer"
val tableName = "dim_date.parquet"

//2. val que contendra el directorio de la capa presentation-layer del bucket de GCP, donde se almacenara la Dim Date
val fileLocationPresentDimDate = s"gs://$bucketName/$layerName/$tableName"

// COMMAND ----------

//Celda que contendra codigo correspondiente a la lectura del archivo csv que contiene ala Dim Time.

import org.apache.spark.sql.functions._ //Importacion de librerias de la libreria general de funciones de spark-sql

//Vals que contienen el directorio y especificacion del tipo de archivo a leer, archivo en formato csv que representa a la Dim Time.
val fileLocationDimTime = "/FileStore/tables/DimTimeStackOverflow_Final.csv"
val fileType = "csv"

//CSV options
val inferSchema = "True"
val firstRowIsHeader = "True"
val delimiter = ";"

//The applied options are for CSV files. For other file types, these will be ignored.
val timeDimensionDF1 = spark.read.format(fileType) 
                   .option("inferSchema", inferSchema) 
                   .option("header", firstRowIsHeader) 
                   .option("sep", delimiter)
                   .option("quote", "\"")
                   .option("escape", "\\") 
                   .option("escape", "\"")
                   .option("multiline", "true")
                   .load(fileLocationDimTime)

//Impresion del Dataframe resultate y correspondiente ala dimension de Tiempo (Time-Dimension)
timeDimensionDF1.show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Time Dimension Writing Process

// COMMAND ----------

//Celda que albergara el correspondiente codigo para el almacenamiento de la DimTime
//Proceso de Escritura 

      timeDimensionDF1
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationPresentDimTime)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Viewing Results Stored in GCP Bucket Partition

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa presentation-layer

//display(dbutils.fs.ls(fileLocationPresentDimTime))


//Visualiazacion del Dataframe correspondiente ala nueva tabla dimDate en la capa presentation-layer
var dimTimeNewDF = spark.read.parquet(fileLocationPresentDimTime)
 
dimTimeNewDF.show()


// COMMAND ----------

//Celda que contendra codigo correspondiente a la lectura del archivo csv que contiene ala Dim Date. 

import org.apache.spark.sql.functions._ //Importacion de librerias de la libreria general de funciones de spark-sql
 
//Vals que contienen el directorio y especificacion del tipo de archivo a leer, archivo en formato csv que representa a la Dim Date.
val fileLocationDimDate = "/FileStore/tables/DimDateStackOverflow_Final.csv"
val fileType = "csv"

//CSV options
val inferSchema = "True"
val firstRowIsHeader = "True"
val delimiter = ";"

//The applied options are for CSV files. For other file types, these will be ignored.
val dateDimensionDF1 = spark.read.format(fileType) 
                   .option("inferSchema", inferSchema) 
                   .option("header", firstRowIsHeader) 
                   .option("sep", delimiter)
                   .option("quote", "\"")
                   .option("escape", "\\") 
                   .option("escape", "\"")
                   .option("multiline", "true")
                   .load(fileLocationDimDate)

//Impresion del Dataframe resultate y correspondiente ala dimension de Fecha (Date-Dimension)         
dateDimensionDF1.show() 

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Date Dimension Writing Process

// COMMAND ----------

//Celda que albergara el correspondiente codigo para el almacenamiento de la DimDate
//Proceso de Escritura
      dateDimensionDF1
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationPresentDimDate)


// COMMAND ----------

// MAGIC %md
// MAGIC ##### Viewing Results Stored in GCP Bucket Partition

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa presentation-layer

//display(dbutils.fs.ls(fileLocationPresentDimDate))


//Visualiazacion del Dataframe correspondiente ala nueva tabla dimDate en la capa presentation-layer
var dimDateNewDF = spark.read.parquet(fileLocationPresentDimDate)
 
dimDateNewDF.show()


