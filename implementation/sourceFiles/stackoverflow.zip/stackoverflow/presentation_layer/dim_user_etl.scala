// Databricks notebook source
// MAGIC %md
// MAGIC # User Dimension
// MAGIC 
// MAGIC 1. Description: Save the context of a user
// MAGIC 2. Granularity: a record represents a user.
// MAGIC 3. Uniqueness policy: the etl will look for users and assign a surrogate key when this question is not stored in the dimension.
// MAGIC 4. Invalidity policy: All fields are required.
// MAGIC 5. SCD Policy: All fields will be Slowly Changing Dimension type one.
// MAGIC 
// MAGIC | Column name        | Display name       | Type     | Source                                           | Comment                 | Sample                                 |
// MAGIC | ------------------ | ------------------ | -------- | ------------------------------------------------ | ----------------------- | -------------------------------------- |
// MAGIC | user_key           | User key           | String   | -                                                | Surragate key generated | 68d2e3f                                |
// MAGIC | id_user_nk              | Id natural key     | Integer  | stakoverflow =>users=>id                         | Natural Key             | 4                                      |
// MAGIC | display_name       | Display name       | Integer  | stakoverflow =>users=>display_name               | -                       | Henry                                  |
// MAGIC | creation_date      | Creation date      | Timestamp | stakoverflow =>users=>creation_date              | -                       | 27/06/2021                             |
// MAGIC | reputation         | Reputation         | Integer  | stakoverflow =>users=>reputation                 | -                       | 10                                     |
// MAGIC | last_access_date   | Last access date   | Timestamp | stakoverflow =>users=>last_access_date           | -                       | 27/06/2021                             |
// MAGIC | down_votes         | Down votes         | Integer  | stakoverflow =>users=>down_votes                 | -                       | 0                                      |
// MAGIC | up_votes           | Up votes           | Integer  | stakoverflow =>users=>up_votes                   | -                       | 1                                      |
// MAGIC | views              | Views              | Integer  | stakoverflow =>users=>views                      | -                       | 1                                      |
// MAGIC | profile_image_url  | Profile image url  | String   | stakoverflow =>users=>profile_image_url          | -                       | https://www.gravatar.com/avatar/730d47 |
// MAGIC | last_gold_badge    | Last gold badge    | String   | stakoverflow =>badges                            | Calculater ETL          | student                                |
// MAGIC | last_silver_badge  | Last silver badge  | String   | stakoverflow =>badges                            | Calculater ETL          | supporter                              |
// MAGIC | last_bronze_badge  | Last bronce badge  | String   | stakoverflow =>badges                            | Calculater ETL          | editor                                 |
// MAGIC | silver_badge_count | Silver badge count | Integer  | stakoverflow =>badges                            | Calculater ETL          | 2                                      |
// MAGIC | bronze_badge_count | Bronze badge count | Integer  | stakoverflow =>badges                            | Calculater ETL          | 2                                      |
// MAGIC | gold_badge_count   | Gold badge count   | Integer  | stakoverflow =>badges                            | Calculater ETL          | 1       

// COMMAND ----------

import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

val bucketName = "idt-stackoverflow"
val stagingLayer = "staging-layer"
val presentationLayer = "presentation-layer"

val badgesTableName = "badges.parquet"
val usersTableName = "users.parquet"

val dimName = "dim_user.parquet"

val badgeStagingPath = s"gs://$bucketName/$stagingLayer/$badgesTableName"
val userStagingPath = s"gs://$bucketName/$stagingLayer/$usersTableName"
val userPresentationPath = s"gs://$bucketName/$presentationLayer/$dimName"

// COMMAND ----------

// MAGIC %md
// MAGIC ###Reading staging tables

// COMMAND ----------

val badgeStagingDF = spark.read.option("inferSchema", "true").parquet(badgeStagingPath)
badgeStagingDF.printSchema()
display(badgeStagingDF)

// COMMAND ----------

val userStagingDF = spark.read.option("inferSchema", "true").parquet(userStagingPath)
userStagingDF.printSchema()
display(userStagingDF)

// COMMAND ----------

val goldBadgesDF = badgeStagingDF
                   .filter(col("class")==="Gold")

val numGoldBadgesByUser = goldBadgesDF
                   .groupBy("user_id")
                   .agg(count("*").alias("gold_badge_count"))

//Condición para obtener la última badge del tipo gold
val goldBadgeCondition = Window.partitionBy("user_id")
                   .orderBy(col("date").desc)
//Particionamos el DF para obtener todas las gold badges por usuario númeradas, empezando de la última obtenida #1
val tempGoldBadgesDF = goldBadgesDF.withColumn("gold_badge_number", dense_rank().over(goldBadgeCondition))

val goldBadgesByLastDate = tempGoldBadgesDF
                  .withColumnRenamed("name","last_gold_badge")
                  .filter(col("gold_badge_number") === "1")
                  .drop(col("gold_badge_number") =!= "1")
//Creamos un DF que contiene la última gold badge, con un count de la misma
val goldBadgesByUserDF = goldBadgesByLastDate
                  .join(numGoldBadgesByUser,Seq("user_id"),"inner")
                  .drop("id","date","class","tag_based","gold_badge_number")

goldBadgesByUserDF.printSchema()
display(goldBadgesByUserDF)


// COMMAND ----------

val silverBadgesDF = badgeStagingDF
                     .filter(col("class")==="Silver")

val numSilverBadgesByUser = silverBadgesDF
                     .groupBy("user_id")
                     .agg(count("*").alias("silver_badge_count"))

//Condición para obtener la última badge del tipo silver
val silverBadgeCondition = Window.partitionBy("user_id")
                     .orderBy(col("date").desc)
val tempSilverBadgesDF = silverBadgesDF
                     .withColumn("silver_badge_number", dense_rank().over(silverBadgeCondition))

val silverBadgesByLastDate = tempSilverBadgesDF
                     .withColumnRenamed("name","last_silver_badge")
                     .filter(col("silver_badge_number") === "1")
                     .drop(col("silver_badge_number") =!= "1")

val silverBadgesByUserDF = silverBadgesByLastDate
                     .join(numSilverBadgesByUser,Seq("user_id"),"inner")
                     .drop("id","date","class","tag_based","silver_badge_number")

silverBadgesByUserDF.printSchema()
display(silverBadgesByUserDF)

// COMMAND ----------

val bronzeBadgesDF = badgeStagingDF
                      .filter(col("class")==="Bronze")

val numBronzeBadgesByUser = bronzeBadgesDF
                      .groupBy("user_id")
                      .agg(count("*").alias("bronze_badge_count"))

//Condición para obtener la última badge del tipo bronze
val bronzeBadgeCondition = Window.partitionBy("user_id")
                      .orderBy(col("date").desc)
val tempBronzeBadgesDF = bronzeBadgesDF
                      .withColumn("bronze_badge_number", dense_rank().over(bronzeBadgeCondition))

val bronzeBadgesByLastDate = tempBronzeBadgesDF
                      .withColumnRenamed("name","last_bronze_badge")
                      .filter(col("bronze_badge_number") === "1")
                      .drop(col("") =!= "1")

val bronzeBadgesByUserDF = bronzeBadgesByLastDate
                      .join(numBronzeBadgesByUser,Seq("user_id"),"inner")
                      .drop("id","date","class","tag_based","bronze_badge_number")

bronzeBadgesByUserDF.printSchema()
display(bronzeBadgesByUserDF)

// COMMAND ----------

val userDF = userStagingDF.withColumnRenamed("id", "user_id")
  
val tempUserDF = userDF
                 .join(goldBadgesByUserDF,Seq("user_id"),"left")
                 .join(silverBadgesByUserDF,Seq("user_id"),"left")
                 .join(bronzeBadgesByUserDF,Seq("user_id"),"left")
                 .withColumn("user_key", expr("uuid()"))
                 .withColumnRenamed("user_id", "id_user_nk")

tempUserDF.printSchema()
display(tempUserDF)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Replacing null values

// COMMAND ----------

val validUserDF = tempUserDF
                    .select(col("user_key"), col("id_user_nk"), col("display_name"), col("creation_date"), col("last_access_date"), col("reputation"),
                    col("up_votes"), col("down_votes"), col("views"), col("profile_image_url"), 
                    (when(tempUserDF("last_gold_badge").isNotNull, col("last_gold_badge")).otherwise("None")).alias("last_gold_badge"),
                    (when(tempUserDF("gold_badge_count").isNotNull, col("gold_badge_count")).otherwise(0)).alias("gold_badge_count"),
                    (when(tempUserDF("last_silver_badge").isNotNull, col("last_silver_badge")).otherwise("None")).alias("last_silver_badge"),
                    (when(tempUserDF("silver_badge_count").isNotNull, col("silver_badge_count")).otherwise(0)).alias("silver_badge_count"),
                    (when(tempUserDF("last_bronze_badge").isNotNull, col("last_bronze_badge")).otherwise("None")).alias("last_bronze_badge"),
                    (when(tempUserDF("bronze_badge_count").isNotNull, col("bronze_badge_count")).otherwise(0)).alias("bronze_badge_count"))

validUserDF.printSchema()
display(validUserDF)

// COMMAND ----------

val undefinedUser = Seq(("0", 0, "Undefined", 0,0,0,0,"Undefined","Undefined", 0, "Undefined",0,"Undefined",0)) 

val tempUndefinedUserDF = undefinedUser .toDF("user_key","id_user_nk","display_name","reputation","up_votes","down_votes","views","profile_image_url","last_gold_badge","gold_badge_count","last_silver_badge","silver_badge_count","last_bronze_badge","bronze_badge_count")

val undefinedUserDF = tempUndefinedUserDF
                        .withColumn("creation_date", current_timestamp())
                        .withColumn("last_access_date", current_timestamp())

undefinedUserDF.printSchema()
display(undefinedUserDF)

// COMMAND ----------

val dimUser = validUserDF.unionByName(undefinedUserDF)

dimUser.printSchema()
display(dimUser)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Writing user dimension

// COMMAND ----------

dimUser.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(userPresentationPath);