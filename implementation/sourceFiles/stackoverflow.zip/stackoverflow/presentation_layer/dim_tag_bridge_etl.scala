// Databricks notebook source
// MAGIC %md
// MAGIC #Tag Bridge
// MAGIC 1. **Description:** The bridge stores the relation between the fact table and the tag table
// MAGIC 2. **Granularity:** A record represents a group of tags for a question
// MAGIC 3. **Uniqueness policy:** The ETL searches the group of tags and assigns a surrogate key when the group of tags is new
// MAGIC 4. **Nulliness policy:** All fields are required
// MAGIC 
// MAGIC | Column name   | Display name  | Type   | Source | Comment                 | Sample  |
// MAGIC | ------------- | ------------- | ------ | ------ | ----------------------- | ------- |
// MAGIC | tag_group_key | Tag group key | String | -      | Surragate key generated | abc-def |
// MAGIC | tag_key       | Tag key       | String | -      | Foreign key to dim_tag  | ghi-jkl |

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val originLayer = "staging-layer"
val detinantionLayer = "presentation-layer"
val tableName = "tag_bridge.parquet"
val dimName = "dim_tag_bridge.parquet"

val origin = s"gs://$bucketName/$originLayer/$tableName"
val destination = s"gs://$bucketName/$detinantionLayer/$dimName"

val tagDim = "dim_tag.parquet"
val originDimTag = s"gs://$bucketName/$detinantionLayer/$tagDim"

// COMMAND ----------

// MAGIC %md
// MAGIC ###Reading tag bridge

// COMMAND ----------

val tagBridge = spark.read.option("inferSchema", "true").parquet(origin)
display(tagBridge)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Reading tag dim

// COMMAND ----------

val tagDim = spark.read.option("inferSchema", "true").parquet(originDimTag)
tagDim.printSchema()
display(tagDim)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Building UUID to Bridge

// COMMAND ----------

val uuidBridge = tagBridge.select("id_post_question").distinct().withColumn("tag_group_key", expr("uuid()"))
display(uuidBridge)

// COMMAND ----------

val tagBridgeUuid = tagBridge.join(uuidBridge, Seq("id_post_question"), "inner")
display(tagBridgeUuid)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Bridge join with tag

// COMMAND ----------

val dimTagBrige = tagBridgeUuid.join(tagDim.select("tag_key", "id_tag_nk"), col("id_tag") === col("id_tag_nk"), "inner")
                                .drop("id_tag", "id_tag_nk")
display(dimTagBrige)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Writing Tag Bridge

// COMMAND ----------

dimTagBrige.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);