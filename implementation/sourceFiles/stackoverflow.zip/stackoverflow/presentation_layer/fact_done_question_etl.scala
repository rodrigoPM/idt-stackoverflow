// Databricks notebook source
// MAGIC %md
// MAGIC 
// MAGIC # Fact_Done_Question
// MAGIC 
// MAGIC 1. Description: Contains all the events that occur in the question asked business process.
// MAGIC 2. Granularity: a record represents a question asked
// MAGIC 3. Uniqueness policy: The Etl will build a record in the fact table based on the new questions that are made in StakOverflow.
// MAGIC 4. Invalidity policy: All fields are required.
// MAGIC 5. Policy of absence of context: When a dimension does not apply to a row of the fact, a foreign key will be defined to indicate the absence of data from it.
// MAGIC 
// MAGIC | Column name    | Display name   | Type    | Source                                               | Comment                                | Sample |
// MAGIC | -------------- | -------------- | ------- | ---------------------------------------------------- | -------------------------------------- | ------ |
// MAGIC | dd_question_key| Dd Question Key| Integer | Dim_question.id_question_nk                          | -                                      | 4      |
// MAGIC | time_key       | Time key       | Integer  | Dim_Time.time_key                                    | Foreign key pointing to Dim_Time       | -      |
// MAGIC | date_key       | Date key       | Integer  | Dim_Date.date_key                                    | Foreign key pointing to Dim_Date       | -      |
// MAGIC | user_key       | User key       | String  | Dim_User.user_key                                    | Foreign key pointing to Dim_User       | -      |
// MAGIC | question_key   | Question key   | String  | Dim_Question.question_key                            | Foreign key pointing to Dim_Question   | -      |
// MAGIC | tag_group_key  | Tag group key  | String  | Dim_Tag_Bridge.tag_group_key                         | Foreign key pointing to Dim_Tag_Bridge | -      |
// MAGIC | answer_count   | Answer count   | Integer | stakoverflow =>post_question=>answer_count  | -                                      | 2      |
// MAGIC | view_count     | View count     | Integer | stakoverflow =>post_question=>view_count    | -                                      | 10     |
// MAGIC | score          | Score          | Integer | stakoverflow =>post_question=>score         | -                                      | 5      |
// MAGIC | comment_count  | Comment count  | Integer | stakoverflow =>post_question=comment_count  | -                                      | 4      |
// MAGIC | revision_count | Revision count | Integer | stakoverflow =>post_history                 | Calculater ETL                         | 1      |
// MAGIC | favorite_count | Favorite count | Integer | stakoverflow =>post_question=favorite_count | -                                      | 2      |
// MAGIC | fac_done_question_key| Fact done question key | String | -     | Primary key generated to fact_done_question| abd-gr7      |

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val stagingLayer = "staging-layer"
val presentationLayer = "presentation-layer"

val postQuestionStagingName = "posts_questions.parquet"

val dimQuestionName = "dim_question.parquet"
val dimUserName = "dim_user.parquet"
val dimTagBridgeName = "dim_tag_bridge.parquet"

val factDoneQuestionName = "fact_done_question.parquet"

val postQuestionStagingPath = s"gs://$bucketName/$stagingLayer/$postQuestionStagingName"

val dimQuestionPath =  s"gs://$bucketName/$presentationLayer/$dimQuestionName"
val dimUserPath = s"gs://$bucketName/$presentationLayer/$dimUserName"
val dimTagBridgePath = s"gs://$bucketName/$presentationLayer/$dimTagBridgeName"


// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading Questions from Staging Layer

// COMMAND ----------

val postQuestionStagingDF = spark.read.option("inferSchema", "true").parquet(postQuestionStagingPath)
postQuestionStagingDF.printSchema()
display(postQuestionStagingDF)

// COMMAND ----------

val dimQuestionDF = spark.read.option("inferSchema", "true").parquet(dimQuestionPath)
dimQuestionDF.printSchema()
display(dimQuestionDF)

// COMMAND ----------

val dimUserDF = spark.read.option("inferSchema", "true").parquet(dimUserPath)
dimUserDF.printSchema()
display(dimUserDF)

// COMMAND ----------

val dimTagBridgeDF = spark.read.option("inferSchema", "true").parquet(dimTagBridgePath)
dimTagBridgeDF.printSchema()
display(dimTagBridgeDF)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Drop unused columns for fact_done_question

// COMMAND ----------

val postQuestionDF = postQuestionStagingDF
                     .select(col("id"),col("answer_count"),col("comment_count"),col("favorite_count"),col("score"), col("view_count"),
                             col("id_creation_date"),col("id_creation_time"),
                             (when(postQuestionStagingDF("owner_user_id").isNotNull, col("owner_user_id")).otherwise(0)).alias("owner_user_id"))
                                                                                            
postQuestionDF.printSchema()
display(postQuestionDF)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Drop unused columns for dim question

// COMMAND ----------

val validDimQuestionDF = dimQuestionDF.drop("id_creation_date")
                                        .drop("id_creation_time")
                                        .drop("score")
                                        .drop("comment_count")
                                        .drop("favorite_count")
                                        .drop("owner_user_id")

validDimQuestionDF.printSchema()
display(validDimQuestionDF)

// COMMAND ----------

// MAGIC %md
// MAGIC #### Create fact done question

// COMMAND ----------

val factDoneQuestion = postQuestionDF.join(validDimQuestionDF,postQuestionDF("id")===validDimQuestionDF("id_question_nk"),"inner")
                                         .join(dimUserDF,postQuestionDF("owner_user_id")===dimUserDF("id_user_nk"), "inner")
                                         .join(dimTagBridgeDF,postQuestionDF("id")===dimTagBridgeDF("id_post_question"),"inner") 
                                         .withColumnRenamed("id","dd_question_key")
                                         .withColumnRenamed("id_creation_date", "date_key")
                                         .withColumnRenamed("id_creation_time", "time_key")
                                         .select("dd_question_key","date_key","user_key","time_key","question_key","tag_group_key","answer_count",
                                                "score","comment_count","favorite_count","view_count")

factDoneQuestion.printSchema()
display(factDoneQuestion)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Save fact done question 

// COMMAND ----------

val factDoneQuestionPath = s"gs://$bucketName/$presentationLayer/$factDoneQuestionName"

factDoneQuestion.write
                  .option("compression", "snappy")
                  .option("header", true)
                  .mode("overwrite")
                  .parquet(factDoneQuestionPath);

// COMMAND ----------

// MAGIC %md
// MAGIC ####Overwrite dim question

// COMMAND ----------

validDimQuestionDF.write
                  .option("compression", "snappy")
                  .option("header", true)
                  .mode("overwrite")
                  .parquet(dimQuestionPath);

// COMMAND ----------

// MAGIC %md
// MAGIC ####Overwrite dim tag bridge

// COMMAND ----------

val dimTagBridge = dimTagBridgeDF.drop("id_post_question")

dimTagBridge.printSchema()
display(dimTagBridge)

// COMMAND ----------

dimTagBridge.write
              .option("compression", "snappy")
              .option("header", true)
              .mode("overwrite")
              .parquet(dimTagBridgePath);