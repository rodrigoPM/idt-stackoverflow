// Databricks notebook source
// MAGIC %md
// MAGIC #Stackoverflow_posts staging

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val originLayer = "raw-layer"
val detinantionLayer = "staging-layer"
val tableName = "stackoverflow_posts.parquet"

val origin = s"gs://$bucketName/$originLayer/$tableName"
val destination = s"gs://$bucketName/$detinantionLayer/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading tags

// COMMAND ----------

val stackoverflowPosts = spark.read.option("inferSchema", "true").parquet(origin)
stackoverflowPosts.printSchema()
display(stackoverflowPosts)

// COMMAND ----------

val stackoverflowPostsStaging = stackoverflowPosts.drop("community_owned_date")
                                .drop("last_editor_display_name")
                                .drop("last_editor_user_id")
display(stackoverflowPostsStaging)

// COMMAND ----------

val newLastEditDate = stackoverflowPostsStaging.filter(col("last_edit_date").isNull).withColumn("last_edit_date", col("creation_date"))
val stackoverflowPostNewLastEditDate = stackoverflowPostsStaging.unionByName(newLastEditDate).filter(col("last_edit_date").isNotNull)
display(stackoverflowPostNewLastEditDate)

// COMMAND ----------

val newLastActivityDate = stackoverflowPostNewLastEditDate.filter(col("last_activity_date").isNull)
                          .withColumn("last_activity_date", col("last_edit_date"))
val stackoverflowPostNewLastActivityDate = stackoverflowPostNewLastEditDate.unionByName(newLastActivityDate).filter(col("last_activity_date").isNotNull)
display(stackoverflowPostNewLastActivityDate)

// COMMAND ----------

import org.apache.spark.sql.types._

val stackoverflowPostsWrite = stackoverflowPostNewLastActivityDate
      .withColumn("id_creation_date", date_format(col("creation_date"),"yyyyMMdd").cast(IntegerType))
      .withColumn("id_creation_time", date_format(col("creation_date"),"HHmmss").cast(IntegerType))
display(stackoverflowPostsWrite.select("creation_date", "id_creation_date", "id_creation_time"))

// COMMAND ----------

stackoverflowPostsWrite.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);