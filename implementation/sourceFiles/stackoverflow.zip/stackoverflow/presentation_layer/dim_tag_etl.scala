// Databricks notebook source
// MAGIC %md
// MAGIC #Tag Dimension
// MAGIC 1. **Description:** Store the tags for the questions
// MAGIC 2. **Granularity:** A record represents a tag
// MAGIC 3. **Uniqueness policy:** The ETL searches the tags and assigns a surrogate key when the tag is new
// MAGIC 4. **Nulliness policy:** All fields are required
// MAGIC 5. **SCD policy:** All fields use SCD 1
// MAGIC 
// MAGIC | Column name | Display name | Type    | Source                    | Comment                 | Sample     |
// MAGIC | ----------- | ------------ | ------- | ------------------------- | ----------------------- | ---------- |
// MAGIC | tag_key     | tag_key      | String  | -                         | Surragate key generated | 68d2e3f    |
// MAGIC | id_tag_nk   | id_nk        | Integer | stakoverflow =>tags.id    | Natural Key             | 1          |
// MAGIC | name        | Name         | String  | stakoverflow =>tag.name   | -                       | JavaScript |
// MAGIC | total_ount  | Count        | Integer | stakoverflow =>tags.count | -                       | 100        |

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val originLayer = "staging-layer"
val detinantionLayer = "presentation-layer"
val tableName = "tags.parquet"
val dimName = "dim_tag.parquet"

val origin = s"gs://$bucketName/$originLayer/$tableName"
val destination = s"gs://$bucketName/$detinantionLayer/$dimName"

// COMMAND ----------

// MAGIC %md
// MAGIC ###Reading tags from staging layer

// COMMAND ----------

val tags = spark.read.option("inferSchema", "true").parquet(origin)
tags.printSchema()
display(tags)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Renamed columns and adding tag_key

// COMMAND ----------

val dimTag = tags.withColumn("tag_key", expr("uuid()"))
                    .withColumnRenamed("count", "total_count")
                    .withColumnRenamed("id", "id_tag_nk")
                    .withColumnRenamed("tag_name", "name")
display(dimTag)

// COMMAND ----------

// MAGIC %md
// MAGIC ###Writing tag dimension

// COMMAND ----------

dimTag.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);