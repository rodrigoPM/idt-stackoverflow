// Databricks notebook source
// MAGIC %md
// MAGIC #### Reading, cleaning and writing process in the raw layer of the posts_moderator_nomination table that will be used for the construction of the Dimensional Model

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Definition of important Global values

// COMMAND ----------

//Path que contendra el directorio de almacenamiento de los resultados de las transformaciones sobre las columnas de las tablas que se utilizaran en este notebook

//1. Vals que contendran informacion concerniente al nombre del bucket , capa a escribir y nombre de la tabla a aplicar el proceso de cleaning y save
 
val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"
val tableName = "posts_moderator_nomination.parquet"

//2. val que contendra el directorio  de la capa raw-layer del bucket de S3 ,donde se almacenara la nueva version de la tabla posts_moderator_nomination  
val fileLocationRawPostsModeratorNomination  = s"gs://$bucketName/$layerName/$tableName"



// COMMAND ----------

// MAGIC %md
// MAGIC ##### 4. Table posts_moderator_nomination  
// MAGIC 
// MAGIC * Schema corresponding to the posts_moderator_nomination table, which comes from a dataset in csv format
// MAGIC 
// MAGIC 
// MAGIC | Column name |  Type    | 
// MAGIC | ----------- |  ------- | 
// MAGIC | id          |  Integer | 
// MAGIC | title        |  String  | 
// MAGIC | body        |  String |
// MAGIC | accepted_answer_id     |  String   |
// MAGIC | answer_count       |  String   |
// MAGIC | comment_count   |  Integer   |
// MAGIC | community_owned_date     |  Timestamp   |
// MAGIC | creation_date       |  Timestamp   |
// MAGIC | favorite_count   |  String   |
// MAGIC | last_activity_date     |  Timestamp   |
// MAGIC | last_edit_date       |  Timestamp   |
// MAGIC | last_editor_display_name   |  String   |
// MAGIC | last_editor_user_id     |  Integer   |
// MAGIC | owner_display_name       | String   |
// MAGIC | owner_user_id   |  Integer   |
// MAGIC | parent_id     |  String   |
// MAGIC | post_type_id       |  Integer   |
// MAGIC | score   |  Integer   |
// MAGIC | tags   |  String   |
// MAGIC | view_count   |  String   |

// COMMAND ----------

// Celda que albergara codigo correspondiente ala  Lectura y creacion del Dataframe posts_moderator_nomination
 
//File location and type
val fileLocation = "s3://idt115-stackoverflow/dataprep/gg13113/posts_moderator_nomination.csv/"
val fileType = "csv"

//CSV options
val inferSchema = "True"
val firstRowIsHeader = "False"
val delimiter = ","

//The applied options are for CSV files. For other file types, these will be ignored.
val postModeratorDF = spark.read.format(fileType) 
                   .option("inferSchema", inferSchema) 
                   .option("header", firstRowIsHeader) 
                   .option("sep", delimiter) 
                   .option("quote", "\"")
                   .option("escape", "\\") 
                   .option("escape", "\"")
                   .option("multiline", "true") 
                   .load(fileLocation)

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de renombrado de las columnas resultantes luego de la creacion del dataframe

//Operacion de renombrado de todas las columnas del dataframe recien creado 
val renameColumnModeratorDF = postModeratorDF.withColumnRenamed("_c0","id")
                      .withColumnRenamed("_c1","title")
                      .withColumnRenamed("_c2","body")
                      .withColumnRenamed("_c3","accepted_answer_id")
                      .withColumnRenamed("_c4","answer_count")
                      .withColumnRenamed("_c5","comment_count")
                      .withColumnRenamed("_c6","community_owned_date")
                      .withColumnRenamed("_c7","creation_date")
                      .withColumnRenamed("_c8","favorite_count")
                      .withColumnRenamed("_c9","last_activity_date")
                      .withColumnRenamed("_c10","last_edit_date")
                      .withColumnRenamed("_c11","last_editor_display_name")
                      .withColumnRenamed("_c12","last_editor_user_id")
                      .withColumnRenamed("_c13","owner_display_name")
                      .withColumnRenamed("_c14","owner_user_id")
                      .withColumnRenamed("_c15","parent_id")
                      .withColumnRenamed("_c16","post_type_id")
                      .withColumnRenamed("_c17","score")
                      .withColumnRenamed("_c18","tags")
                      .withColumnRenamed("_c19","view_count")

// COMMAND ----------

//Celda que albergara codigo correspondiente a las operaciones de filtrado para todos los registros no nulos y la correspondiente impresion de los resutados


//Operacion de filtrado para todos aquellos registros cuyo id sea diferente de null 
val filterColumnModeratorDF= renameColumnModeratorDF.filter($"id".isNotNull)
     
//Operacion de Impresion del dataframe resultante 
filterColumnModeratorDF.show()

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Process of Writing results in the Raw-Layer layer for the new table post_moderator_nomination

// COMMAND ----------

//Proceso de Escritura 

      filterColumnModeratorDF
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationRawPostsModeratorNomination)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Visualization of Results stored in the S3 bucket partition 

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa raw layer

//display(dbutils.fs.ls(fileLocationRawPostsModeratorNomination))


//Visualiazacion del Dataframe correspondiente ala nueva tabla post_moderator_nomination_ en la capa raw layer
var postModeratorNewDF = spark.read.parquet(fileLocationRawPostsModeratorNomination)
display(postModeratorNewDF)