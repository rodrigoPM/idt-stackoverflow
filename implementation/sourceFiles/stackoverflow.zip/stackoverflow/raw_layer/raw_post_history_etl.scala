// Databricks notebook source
// MAGIC %md
// MAGIC ###Reading, cleaning and writing post_history table in the row layer, it will be used to construct the fact_done_question fact table

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Global variables definition and reading data from S3

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"

val location = "s3://idt115-stackoverflow/dataprep/mm14031/post_history.csv/"
val destination = s"gs://$bucketName/$layerName/post_history.parquet"

val dirtyTable = spark.read
  .option("sep", ",")
  .option("header", false)
  .option("inferSchema", true)
  .option("quote", "\"")
  .option("escape", "\\")
  .option("escape", "\"")
  .option("multiline", true)
  .csv(location)

dirtyTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC #####Table post_history
// MAGIC * Schema corresponding to post_history table
// MAGIC 
// MAGIC | Column name             |  Type      | 
// MAGIC | -----------             |  -------   | 
// MAGIC | id                      |  Integer   | 
// MAGIC | creation_date                   |  Timestamp    | 
// MAGIC | post_id                    |  Integer    |
// MAGIC | post_history_type_id      |  Integer   |
// MAGIC | revision_guid            |  String   |
// MAGIC | user_id           |  Integer   |
// MAGIC | text    |  String |
// MAGIC | comment           |  String |

// COMMAND ----------

// MAGIC %md
// MAGIC #####Setting columns name

// COMMAND ----------

// Set correct names to columns
val postHistory = dirtyTable
  .withColumnRenamed("_c0","id")
  .withColumnRenamed("_c1","creation_date")
  .withColumnRenamed("_c2","post_id")
  .withColumnRenamed("_c3","post_history_type_id")
  .withColumnRenamed("_c4","revision_guid")
  .withColumnRenamed("_c5","user_id")
  .withColumnRenamed("_c6","text")
  .withColumnRenamed("_c7","comment")

postHistory.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC #####Verifying ids not null

// COMMAND ----------

val validPostHistory = postHistory.filter(col("id").isNotNull)
println(validPostHistory.count())

// COMMAND ----------

// MAGIC %md
// MAGIC #####Saving data to raw layer (Google cloud)

// COMMAND ----------

validPostHistory.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);

// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading stored data from Google cloud

// COMMAND ----------

val snappyPostHistory = spark.read
  .option("sep", ",")
  .option("header", true)
  .option("inferSchema", true)
  .parquet(destination)

snappyPostHistory.show(5)