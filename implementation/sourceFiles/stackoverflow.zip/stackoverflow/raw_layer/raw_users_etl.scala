// Databricks notebook source
// MAGIC %md
// MAGIC ###Reading, cleaning and writing users table in the row layer, it will be used to construct the dim_user dimension

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Global variables definition and reading data from S3

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"

val location = "s3://idt115-stackoverflow/dataprep/pm15007/users.csv/"
val destination = s"gs://$bucketName/$layerName/users.parquet"

val dirtyTable = spark.read
  .option("sep", ",")
  .option("header", false)
  .option("inferSchema", true)
  .option("quote", "\"")
  .option("escape", "\\")
  .option("escape", "\"")
  .option("multiline", true)
  .csv(location)

dirtyTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC #####Table users
// MAGIC * Schema corresponding to users table
// MAGIC 
// MAGIC | Column name             |  Type    | 
// MAGIC | -----------             |  ------- | 
// MAGIC | id                      |  Integer | 
// MAGIC | display_name            |  String  | 
// MAGIC | about_me                |  String |
// MAGIC | age                     |  String   |
// MAGIC | creation_date           |  Timestamp   |
// MAGIC | last_access_date        |  Timestamp   |
// MAGIC | location                |  String   |
// MAGIC | reputation              |  Integer   |
// MAGIC | up_votes                |  Integer   |
// MAGIC | down_votes              |  Integer   |
// MAGIC | views                   |  Integer   |
// MAGIC | profile_image_url       |  String   |
// MAGIC | website_url             |  String   |

// COMMAND ----------

// MAGIC %md
// MAGIC #####Setting columns name

// COMMAND ----------

// Set correct names to columns
val users = dirtyTable
  .withColumnRenamed("_c0","id")
  .withColumnRenamed("_c1","display_name")
  .withColumnRenamed("_c2","about_me")
  .withColumnRenamed("_c3","age")
  .withColumnRenamed("_c4","creation_date")
  .withColumnRenamed("_c5","last_access_date")
  .withColumnRenamed("_c6","location")
  .withColumnRenamed("_c7","reputation")
  .withColumnRenamed("_c8","up_votes")
  .withColumnRenamed("_c9","down_votes")
  .withColumnRenamed("_c10","views")
  .withColumnRenamed("_c11","profile_image_url")
  .withColumnRenamed("_c12","website_url")

users.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC #####Verifying ids not null

// COMMAND ----------

val validUsers = users.filter(col("id").isNotNull)
validUsers.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC #####Saving data to raw layer (Google cloud)

// COMMAND ----------


validUsers.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);