// Databricks notebook source
// MAGIC %md
// MAGIC #Votes staging

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val originLayer = "raw-layer"
val detinantionLayer = "staging-layer"
val tableName = "votes.parquet"

val origin = s"gs://$bucketName/$originLayer/$tableName"
val destination = s"gs://$bucketName/$detinantionLayer/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading votes

// COMMAND ----------

val rawVotes = spark.read.option("inferSchema", "true").parquet(origin)
rawVotes.printSchema()
display(rawVotes)

// COMMAND ----------

rawVotes.select("vote_type_id").distinct.show()

// COMMAND ----------

val voteTypes = Map(1->"AcceptedByOriginator", 
                    2->"UpVote", 
                    3->"Downvote",
                    4->"Offensive",
                    5->"Favorite", 
                    6->"Close", 
                    7->"Reopen", 
                    8->"BountyStart", 
                    9->"BountyClose", 
                    10->"Deletion", 
                    11->"Undeletion", 
                    12->"Spam",
                    15->"ModeratorReview", 
                    16->"ApproveEditSuggestion")

def getVoteTypeByMap(voteTypeId: Integer): String = {
  if(voteTypes.contains(voteTypeId)) voteTypes(voteTypeId) else "Unknown";
}

val getVoteType = udf(getVoteTypeByMap _)

// COMMAND ----------

val votes = rawVotes.withColumn("vote_type", getVoteType(col("vote_type_id")))
display(votes)

// COMMAND ----------

votes.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);