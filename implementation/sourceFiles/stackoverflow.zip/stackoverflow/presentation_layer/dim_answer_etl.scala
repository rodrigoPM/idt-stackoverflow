// Databricks notebook source
// MAGIC %md
// MAGIC ####  Reading process, transformation, construction and writing in the Presentation Layer of the Dim Answer that will be part of the dimensional model

// COMMAND ----------

// MAGIC %md
// MAGIC 
// MAGIC # Dim Answer
// MAGIC 
// MAGIC 1. Description: Saves the context of the answer made.
// MAGIC 2. Granularity: a record represents a reply post.
// MAGIC 3. Uniqueness policy: the etl will search for responses and assign a surrogate key when this response is not stored in the dimension.
// MAGIC 4. Invalidity policy: All fields are required.
// MAGIC 5. SCD Policy: All fields will be Slowly Changing Dimension type one
// MAGIC 
// MAGIC | Column name        | Display name       | Type     | Source                                                    | Comment                 | Sample            |
// MAGIC | ------------------ | ------------------ | -------- | --------------------------------------------------------- | ----------------------- | ----------------- |
// MAGIC | answer_key         | Answer Key         | String   | -                                                         | Surragate key generated | 68d2e3f           |
// MAGIC | id_answer_nk       | Id natural key     | Integer  | stakoverflow =>post_answer=>id                            | Natural Key             | 4                 |
// MAGIC | last_activity_date | Last activity date | Timestamp| stakoverflow =>post_answer=>last_activity_date            | -                       | 27/06/2021        |
// MAGIC | last_edit_date     | Last edit date     | Timestamp| stakoverflow =>post_answer=>last_edit_date                | -                       | 27/06/2021        |
// MAGIC | creation_date      | Creation date      | Timestamp| stakoverflow =>post_answer=>creation_date                 | -                       | 27/06/2021        |

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Defining important Global values for the staging-layer partition

// COMMAND ----------

//Path que contendrá el directorio de almacenamiento del marco de datos post_answer a partir del cual se construirá Dim Answer

//1. Vals que contendran informacion concerniente al nombre del bucket , capa que albergara las tablas o dataframe a utilizar para la construccion de la dimension
val bucketName = "idt-stackoverflow"
val layerName = "staging-layer"
val tableName = "post_answer.parquet"


//2. val que contendra el directorio de la capa staging-layer del bucket de GCP , donde esta almacenada  version actual del dataframe post_answer
val fileLocationStagingPostAnswer = s"gs://$bucketName/$layerName/$tableName"


// COMMAND ----------

// MAGIC %md
// MAGIC ##### Defining important Global values for the presentation-layer partition

// COMMAND ----------

//Path que contendra el directorio de almacenamiento para la nueva Dimension Answer (Dim Answer)

//1. Vals que contendran informacion concerniente al nombre del bucket , capa que albergara la nueva Dim Answer
val bucketName = "idt-stackoverflow"
val layerName = "presentation-layer"
val tableName = "dim_answer.parquet"


//2. val que contendra el directorio de la capa presentation-layer donde se almacenara la Dim Answer
val fileLocationPresentDimAnswer = s"gs://$bucketName/$layerName/$tableName"

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Previous Transformations on the post_answer Dataframe

// COMMAND ----------

//Celda que albergara codigo correspondiente a operaciones basicas de tratamiento de datos para las columnas id que seran utilizadas para construir la dimension
import org.apache.spark.sql.functions._ //Importacion de las funciones de la libreria general de funciones de spark-sqñ

//Operacion de lectura del Dataframe correspondiente a post_answer desde la capa staging-layer
val postAnswerDF1 = spark.read.parquet(fileLocationStagingPostAnswer) 


// COMMAND ----------

//Celda aque albergara codigo correspondiente a operaciones de filtrado especificamente sobre el campo "owner_user_id" como parte de la aplicacion de buenas practicas de construccion de los Modelos Dimensionales

//Operacion de filtrado para el campo "owner_user_id" cuyo contiendo es "It has no owner id"
val postIsAnswerDF1 =  postAnswerDF1.filter($"owner_user_id"==="It has no owner id")

//Operacion de filtrado para el campo "owner_user_id" cuyo contenido es diferente a "It has no owner id"
val postNotAnswerDF1 = postAnswerDF1.filter($"owner_user_id"=!="It has no owner id")


// COMMAND ----------

//Celda que albergara codigo correspondiente a operaciones de creacion de una nueva columna , validacion, sustitucion de valores con contenido textual por un valor entero y union del dataframe que contiene los registros para el campo "owner_user_id" diferentes a "It has no owner id" , y el dataframe resultante de la operacion de sustitucion de registros con valor textual ("It has no owner id") por un numero entero "0"


//Operacion de creacion de nueva columna y  sustitucion para para el campo "owner_user_id para  todos aquellos registros con valores textuales ("It has no owner id") por un valor entero ("0")  
val postIsAnswerDF2 = postIsAnswerDF1.withColumn("owner_user_id",when(postIsAnswerDF1("owner_user_id")==="It has no owner id",0))

//Operacion de union del Dataframe filtrado con contenido diferente a "It has no owner id" y las filas del dataframe recientemente ajustadas con el valor entero "0"  en sustitucion de registros con el valor "It has no owner id"
val postFinalAnswerDF4 = postNotAnswerDF1.unionByName(postIsAnswerDF2)



// COMMAND ----------

//Celda que albergara operaciones de filtrado para el nuevo campo "owner_user_id" , para la correspondiente comparacion de su contenido , para los registros con contenido ="0" y diferente de "0"

//Operacion de filtrado para todos aquellos registros con valor igual a 0
val filterOwnerAnswerDF = postFinalAnswerDF4.filter($"owner_user_id"===0).show()

//Operacion de filtrado para todos aquellos registros con valor diferente de 0
//val filterOwnerAnswerDF = postFinalAnswerDF4.filter($"owner_user_id"=!=0).show()

//Operacion de filtrado para todos aquellos registros con valor igual a "It has no owner id"
//val filterOwnerAnswerDF = postFinalAnswerDF4.filter($"owner_user_id"==="It has no owner id").show()

// COMMAND ----------

//Operacion de seleccion y casteo a tipo int para todas las columnas cuyo contenido es id y que formaran parte de la version final de la Dim Answer
val postCastAnswerDF = postFinalAnswerDF4.select($"id".cast("int"),$"id_creation_date".cast("int"),$"id_creation_time".cast("int"),$"last_activity_date",$"last_edit_date",$"creation_date",
                                         $"score",$"comment_count",$"parent_id".cast("int"),$"owner_user_id".cast("int"))
 

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Definition of the Initial Load Operation that will build the Dim Answer

// COMMAND ----------

//Celda que albergara codigo correspondiente a operaciones necesarias para la construccion de la Dim Answer 
 
 //Operacion de creacion una nueva columna para la llave subrogada de la Dim Answer y seleccion de las columnas finales que conformaran la misma
val newDimAnswerDF = postCastAnswerDF.withColumn("answer_key",expr("uuid()"))
                    .select($"answer_key",$"id".as("id_answer_nk"),$"id_creation_date",$"id_creation_time",$"last_activity_date",$"last_edit_date",$"creation_date",$"score",$"comment_count",$"parent_id",$"owner_user_id")

//println(newDimAnswerDF2.count())

//Operacion de impresion del Dataframe correspondiente ala Dim Answer
display(newDimAnswerDF)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Writing process of results in the layer Presentation-Layer

// COMMAND ----------

//Proceso de Escritura 
       newDimAnswerDF
      .write
      .option("compression", "snappy")
      .mode("overwrite")
      .parquet(fileLocationPresentDimAnswer)

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Viewing Results Stored in GCP Bucket Partition

// COMMAND ----------

//Visualiacion del contenido del directorio de almacenamiento en la capa presentation-layer

//display(dbutils.fs.ls(fileLocationPresentDimAnswerr))


//Visualiazacion del Dataframe correspondiente ala nueva tabla badges en la capa staging-layer
var DimAnswerNewDF = spark.read.parquet(fileLocationPresentDimAnswer)
 
fileLocationPresentDimAnswer.show()
