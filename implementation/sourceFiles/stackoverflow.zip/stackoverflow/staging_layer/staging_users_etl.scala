// Databricks notebook source
// MAGIC %md
// MAGIC #users table
// MAGIC ####Reading table

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val rowLayer = "raw-layer"
val stagingLayer = "staging-layer"

val location = s"gs://$bucketName/$rowLayer/users.parquet/"
val destination = s"gs://$bucketName/$stagingLayer/users.parquet"

val rowTable = spark.read
  .option("sep", ",")
  .option("header", true)
  .option("inferSchema", true)
  .parquet(location)

rowTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC ###Schema
// MAGIC | Column name             |  Type     | 
// MAGIC | -----------             |  -------  | 
// MAGIC | id                      |  Integer  | 
// MAGIC | display_name            |  String   | 
// MAGIC | creation_date           |  Timestamp|
// MAGIC | last_access_date        |  Timestamp|
// MAGIC | reputation              |  Integer  |
// MAGIC | up_votes                |  Integer  |
// MAGIC | down_votes              |  Integer  |
// MAGIC | views                   |  Integer  |
// MAGIC | profile_image_url       |  String   |

// COMMAND ----------

// MAGIC %md
// MAGIC ##Drop unused columns

// COMMAND ----------

// Drop unused columns 
val users = rowTable
  .drop("about_me", "age", "location", "website_url")
  .withColumnRenamed("profile_image_url", "temp_profile_image_url")
  
users.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ####Replacing null values

// COMMAND ----------

// Checking null values for temp_profile_image_url column
val validUsers = users
  .select(col("id"), col("display_name"), col("creation_date"), col("last_access_date"), col("reputation"), col("up_votes"), col("down_votes"), col("views"),
   (when(users("temp_profile_image_url").isNotNull, col("temp_profile_image_url"))
  .otherwise("Undefined")).alias("profile_image_url"))

validUsers.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC ##Save data to staging layer

// COMMAND ----------

validUsers.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);