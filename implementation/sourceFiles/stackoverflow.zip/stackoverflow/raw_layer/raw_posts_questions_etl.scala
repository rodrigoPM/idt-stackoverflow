// Databricks notebook source
// MAGIC %md
// MAGIC ###Reading, cleaning and writing posts_questions table in the row layer, it will be used to construct the fact_done_question fact table

// COMMAND ----------

// MAGIC %md
// MAGIC ##### Global variables definition and reading data from S3

// COMMAND ----------

import org.apache.spark.sql.functions._

val bucketName = "idt-stackoverflow"
val layerName = "raw-layer"

val location = "s3://idt115-stackoverflow/dataprep/mm14031/posts_questions.csv/"
val destination = s"gs://$bucketName/$layerName/posts_questions.parquet"

val dirtyTable = spark.read
  .option("sep", ",")
  .option("header", false)
  .option("inferSchema", true)
  .option("quote", "\"")
  .option("escape", "\\")
  .option("escape", "\"")
  .option("multiline", true)
  .csv(location)

dirtyTable.printSchema()

// COMMAND ----------

// MAGIC %md
// MAGIC #####Table post_questions
// MAGIC * Schema corresponding to post_questions table
// MAGIC 
// MAGIC | Column name             |  Type      | 
// MAGIC | -----------             |  -------   | 
// MAGIC | id                      |  Integer   | 
// MAGIC | title                   |  String    | 
// MAGIC | body                    |  String    |
// MAGIC | accepted_answer_id      |  Integer   |
// MAGIC | answer_count            |  Integer   |
// MAGIC | comment_count           |  Integer   |
// MAGIC | community_owned_date    |  Timestamp |
// MAGIC | creation_date           |  Timestamp |
// MAGIC | favorite_count          |  Integer   |
// MAGIC | last_activity_date      |  Timestamp |
// MAGIC | last_edit_date          |  Timestamp |
// MAGIC | last_editor_display_name|  String    |
// MAGIC | last_editor_user_id     |  Integer   |
// MAGIC | owner_display_name      |  String    |
// MAGIC | owner_user_id           |  Integer   |
// MAGIC | parent_id               |  String    |
// MAGIC | post_type_id            |  Integer   |
// MAGIC | score                   |  Integer   |
// MAGIC | tags                    |  String    |
// MAGIC | view_count              |  Integer   |

// COMMAND ----------

// MAGIC %md
// MAGIC #####Setting columns name

// COMMAND ----------

// Set correct names to columns
val postsQuestions = dirtyTable
  .withColumnRenamed("_c0","id")
  .withColumnRenamed("_c1","title")
  .withColumnRenamed("_c2","body")
  .withColumnRenamed("_c3","accepted_answer_id")
  .withColumnRenamed("_c4","answer_count")
  .withColumnRenamed("_c5","comment_count")
  .withColumnRenamed("_c6","community_owned_date")
  .withColumnRenamed("_c7","creation_date")
  .withColumnRenamed("_c8","favorite_count")
  .withColumnRenamed("_c9","last_activity_date")
  .withColumnRenamed("_c10","last_edit_date")
  .withColumnRenamed("_c11","last_editor_display_name")
  .withColumnRenamed("_c12","last_editor_user_id")
  .withColumnRenamed("_c13","owner_display_name")
  .withColumnRenamed("_c14","owner_user_id")
  .withColumnRenamed("_c15","parent_id")
  .withColumnRenamed("_c16","post_type_id")
  .withColumnRenamed("_c17","score")
  .withColumnRenamed("_c18","tags")
  .withColumnRenamed("_c19","view_count")

postsQuestions.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC #####Verifying ids not null

// COMMAND ----------

println(postsQuestions.count())
val validPostsQuestions = postsQuestions.filter(col("id").isNotNull)
println(validPostsQuestions.count())
validPostsQuestions.show(5)

// COMMAND ----------

// MAGIC %md
// MAGIC #####Saving data to raw layer (Google cloud)

// COMMAND ----------

validPostsQuestions.write
  .option("compression", "snappy")
  .option("header", true)
  .mode("overwrite")
  .parquet(destination);

// COMMAND ----------

// MAGIC %md
// MAGIC #####Reading stored data from Google cloud

// COMMAND ----------

val snappyPostsQuestions = spark.read
  .option("sep", ",")
  .option("header", true)
  .option("inferSchema", true)
  .parquet(destination)

snappyPostsQuestions.show(5)